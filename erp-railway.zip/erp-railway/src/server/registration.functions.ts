import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { drugRegistrations, products } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getRegistrations = createServerFn().handler(async () => {
  return db
    .select({
      id: drugRegistrations.id,
      productId: drugRegistrations.productId,
      productName: products.name,
      registrationNumber: drugRegistrations.registrationNumber,
      issueDate: drugRegistrations.issueDate,
      expiryDate: drugRegistrations.expiryDate,
      registrationFee: drugRegistrations.registrationFee,
      renewalFee: drugRegistrations.renewalFee,
      status: drugRegistrations.status,
      notes: drugRegistrations.notes,
      createdAt: drugRegistrations.createdAt,
    })
    .from(drugRegistrations)
    .innerJoin(products, eq(drugRegistrations.productId, products.id))
    .orderBy(drugRegistrations.expiryDate);
});

export const createRegistration = createServerFn({ method: "POST" })
  .inputValidator((d: {
    productId: number; registrationNumber?: string; issueDate?: string;
    expiryDate?: string; registrationFee?: string; renewalFee?: string;
    status?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [r] = await db.insert(drugRegistrations).values(data).returning();
    return r;
  });

export const updateRegistration = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; registrationNumber?: string; issueDate?: string;
    expiryDate?: string; registrationFee?: string; renewalFee?: string;
    status?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [r] = await db.update(drugRegistrations).set(rest).where(eq(drugRegistrations.id, id)).returning();
    return r;
  });

export const deleteRegistration = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(drugRegistrations).where(eq(drugRegistrations.id, data.id));
    return { success: true };
  });
