import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { expenses, products } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getExpenses = createServerFn().handler(async () => {
  return db
    .select({
      id: expenses.id,
      description: expenses.description,
      amount: expenses.amount,
      expenseType: expenses.expenseType,
      category: expenses.category,
      department: expenses.department,
      expenseDate: expenses.expenseDate,
      reference: expenses.reference,
      productId: expenses.productId,
      productName: products.name,
      notes: expenses.notes,
      createdAt: expenses.createdAt,
    })
    .from(expenses)
    .leftJoin(products, eq(expenses.productId, products.id))
    .orderBy(expenses.expenseDate);
});

export const createExpense = createServerFn({ method: "POST" })
  .inputValidator((d: {
    description: string; amount: string; expenseType: string;
    category: string; department?: string; expenseDate?: string;
    reference?: string; productId?: number; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [e] = await db.insert(expenses).values(data).returning();
    return e;
  });

export const updateExpense = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; description?: string; amount?: string; expenseType?: string;
    category?: string; department?: string; expenseDate?: string;
    reference?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [e] = await db.update(expenses).set(rest).where(eq(expenses.id, id)).returning();
    return e;
  });

export const deleteExpense = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(expenses).where(eq(expenses.id, data.id));
    return { success: true };
  });
