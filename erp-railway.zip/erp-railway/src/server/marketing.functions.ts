import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { marketingCampaigns, salesTargets, products, distributors } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getCampaigns = createServerFn().handler(async () => {
  return db
    .select({
      id: marketingCampaigns.id,
      name: marketingCampaigns.name,
      productId: marketingCampaigns.productId,
      productName: products.name,
      startDate: marketingCampaigns.startDate,
      endDate: marketingCampaigns.endDate,
      budget: marketingCampaigns.budget,
      actualSpend: marketingCampaigns.actualSpend,
      status: marketingCampaigns.status,
      notes: marketingCampaigns.notes,
    })
    .from(marketingCampaigns)
    .leftJoin(products, eq(marketingCampaigns.productId, products.id))
    .orderBy(marketingCampaigns.startDate);
});

export const createCampaign = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string; productId?: number; startDate?: string; endDate?: string;
    budget?: string; actualSpend?: string; status?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [c] = await db.insert(marketingCampaigns).values(data).returning();
    return c;
  });

export const updateCampaign = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; name?: string; startDate?: string; endDate?: string;
    budget?: string; actualSpend?: string; status?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [c] = await db.update(marketingCampaigns).set(rest).where(eq(marketingCampaigns.id, id)).returning();
    return c;
  });

export const deleteCampaign = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(marketingCampaigns).where(eq(marketingCampaigns.id, data.id));
    return { success: true };
  });

export const getSalesTargets = createServerFn().handler(async () => {
  return db
    .select({
      id: salesTargets.id,
      productId: salesTargets.productId,
      productName: products.name,
      distributorId: salesTargets.distributorId,
      distributorName: distributors.name,
      year: salesTargets.year,
      month: salesTargets.month,
      targetQuantity: salesTargets.targetQuantity,
      targetAmount: salesTargets.targetAmount,
    })
    .from(salesTargets)
    .leftJoin(products, eq(salesTargets.productId, products.id))
    .leftJoin(distributors, eq(salesTargets.distributorId, distributors.id))
    .orderBy(salesTargets.year, salesTargets.month);
});

export const createSalesTarget = createServerFn({ method: "POST" })
  .inputValidator((d: {
    productId?: number; distributorId?: number; year: number;
    month?: number; targetQuantity?: number; targetAmount?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [t] = await db.insert(salesTargets).values(data).returning();
    return t;
  });

export const deleteSalesTarget = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(salesTargets).where(eq(salesTargets.id, data.id));
    return { success: true };
  });
