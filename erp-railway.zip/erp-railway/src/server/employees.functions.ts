import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { employees } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getEmployees = createServerFn().handler(async () => {
  return db.select().from(employees).orderBy(employees.name);
});

export const createEmployee = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string; department: string; position: string;
    salary?: string; hireDate?: string; status?: string;
    phone?: string; email?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [e] = await db.insert(employees).values(data).returning();
    return e;
  });

export const updateEmployee = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; name?: string; department?: string; position?: string;
    salary?: string; hireDate?: string; status?: string;
    phone?: string; email?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [e] = await db.update(employees).set(rest).where(eq(employees.id, id)).returning();
    return e;
  });

export const deleteEmployee = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(employees).where(eq(employees.id, data.id));
    return { success: true };
  });
