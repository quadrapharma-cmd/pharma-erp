import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { distributors } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getDistributors = createServerFn().handler(async () => {
  return db.select().from(distributors).orderBy(distributors.name);
});

export const createDistributor = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string; address?: string; contactPerson?: string;
    phone?: string; email?: string; creditLimit?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [d2] = await db.insert(distributors).values(data).returning();
    return d2;
  });

export const updateDistributor = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; name?: string; address?: string; contactPerson?: string;
    phone?: string; email?: string; creditLimit?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [d2] = await db.update(distributors).set(rest).where(eq(distributors.id, id)).returning();
    return d2;
  });

export const deleteDistributor = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(distributors).where(eq(distributors.id, data.id));
    return { success: true };
  });
