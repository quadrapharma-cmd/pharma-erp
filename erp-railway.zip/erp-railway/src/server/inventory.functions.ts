import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { goodsReceipts, inventory, products, productionOrders } from "../../db/schema.js";
import { eq, sql } from "drizzle-orm";

export const getGoodsReceipts = createServerFn().handler(async () => {
  return db
    .select({
      id: goodsReceipts.id,
      productId: goodsReceipts.productId,
      productName: products.name,
      productionOrderId: goodsReceipts.productionOrderId,
      quantityReceived: goodsReceipts.quantityReceived,
      batchNumber: goodsReceipts.batchNumber,
      expiryDate: goodsReceipts.expiryDate,
      receiptDate: goodsReceipts.receiptDate,
      unitCost: goodsReceipts.unitCost,
      notes: goodsReceipts.notes,
    })
    .from(goodsReceipts)
    .innerJoin(products, eq(goodsReceipts.productId, products.id))
    .orderBy(goodsReceipts.createdAt);
});

export const createGoodsReceipt = createServerFn({ method: "POST" })
  .inputValidator((d: {
    productId: number; productionOrderId?: number; quantityReceived: number;
    batchNumber?: string; expiryDate?: string; receiptDate?: string;
    unitCost?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [r] = await db.insert(goodsReceipts).values(data).returning();
    // Update inventory
    const existing = await db.select().from(inventory)
      .where(eq(inventory.productId, data.productId));
    if (existing.length > 0) {
      await db.update(inventory)
        .set({ quantity: sql`${inventory.quantity} + ${data.quantityReceived}`, updatedAt: new Date() })
        .where(eq(inventory.productId, data.productId));
    } else {
      await db.insert(inventory).values({
        productId: data.productId,
        batchNumber: data.batchNumber,
        quantity: data.quantityReceived,
        unitCost: data.unitCost,
        expiryDate: data.expiryDate,
      });
    }
    return r;
  });

export const getInventory = createServerFn().handler(async () => {
  return db
    .select({
      id: inventory.id,
      productId: inventory.productId,
      productName: products.name,
      batchNumber: inventory.batchNumber,
      quantity: inventory.quantity,
      unitCost: inventory.unitCost,
      expiryDate: inventory.expiryDate,
      updatedAt: inventory.updatedAt,
    })
    .from(inventory)
    .innerJoin(products, eq(inventory.productId, products.id))
    .orderBy(products.name);
});
