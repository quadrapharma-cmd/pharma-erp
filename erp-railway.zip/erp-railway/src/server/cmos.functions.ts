import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { cmos } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getCmos = createServerFn().handler(async () => {
  return db.select().from(cmos).orderBy(cmos.name);
});

export const createCmo = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string; address?: string; contactPerson?: string;
    phone?: string; email?: string; licenseNumber?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [c] = await db.insert(cmos).values(data).returning();
    return c;
  });

export const updateCmo = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; name?: string; address?: string; contactPerson?: string;
    phone?: string; email?: string; licenseNumber?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [c] = await db.update(cmos).set(rest).where(eq(cmos.id, id)).returning();
    return c;
  });

export const deleteCmo = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(cmos).where(eq(cmos.id, data.id));
    return { success: true };
  });
