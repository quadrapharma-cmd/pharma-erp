import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { expenses, deliveryOrders, productionOrders, budgetLines, inventory, products } from "../../db/schema.js";
import { eq, sum, and } from "drizzle-orm";
import { sql } from "drizzle-orm";

export const getFinancialSummary = createServerFn().handler(async () => {
  // إجمالي الإيرادات (من أوامر التوريد المسلمة)
  const revenueResult = await db
    .select({ total: sum(deliveryOrders.totalAmount) })
    .from(deliveryOrders)
    .where(eq(deliveryOrders.status, "delivered"));
  const totalRevenue = Number(revenueResult[0]?.total ?? 0);

  // إجمالي التكاليف المباشرة
  const directCostResult = await db
    .select({ total: sum(expenses.amount) })
    .from(expenses)
    .where(eq(expenses.expenseType, "direct"));
  const totalDirectCosts = Number(directCostResult[0]?.total ?? 0);

  // إجمالي التكاليف غير المباشرة
  const indirectCostResult = await db
    .select({ total: sum(expenses.amount) })
    .from(expenses)
    .where(eq(expenses.expenseType, "indirect"));
  const totalIndirectCosts = Number(indirectCostResult[0]?.total ?? 0);

  // تكاليف الإنتاج
  const productionCostResult = await db
    .select({ total: sum(productionOrders.totalCost) })
    .from(productionOrders);
  const totalProductionCosts = Number(productionCostResult[0]?.total ?? 0);

  const totalCosts = totalDirectCosts + totalIndirectCosts + totalProductionCosts;
  const netProfit = totalRevenue - totalCosts;

  return {
    totalRevenue,
    totalDirectCosts,
    totalIndirectCosts,
    totalProductionCosts,
    totalCosts,
    netProfit,
    profitMargin: totalRevenue > 0 ? ((netProfit / totalRevenue) * 100).toFixed(2) : "0.00",
  };
});

export const getExpensesByCategory = createServerFn().handler(async () => {
  return db
    .select({
      category: expenses.category,
      expenseType: expenses.expenseType,
      total: sum(expenses.amount),
    })
    .from(expenses)
    .groupBy(expenses.category, expenses.expenseType)
    .orderBy(expenses.expenseType, expenses.category);
});

export const getBudgetVsActual = createServerFn().handler(async () => {
  const budget = await db.select().from(budgetLines).orderBy(budgetLines.category);
  const actual = await db
    .select({
      category: expenses.category,
      total: sum(expenses.amount),
    })
    .from(expenses)
    .groupBy(expenses.category);

  const actualMap = new Map(actual.map(a => [a.category, Number(a.total ?? 0)]));

  return budget.map(b => ({
    ...b,
    actualAmount: actualMap.get(b.category) ?? 0,
    variance: Number(b.budgetedAmount) - (actualMap.get(b.category) ?? 0),
  }));
});

export const getInventoryValue = createServerFn().handler(async () => {
  return db
    .select({
      productId: inventory.productId,
      productName: products.name,
      quantity: inventory.quantity,
      unitCost: inventory.unitCost,
      totalValue: sql<number>`${inventory.quantity} * COALESCE(${inventory.unitCost}::numeric, 0)`,
    })
    .from(inventory)
    .innerJoin(products, eq(inventory.productId, products.id))
    .orderBy(products.name);
});

export const getMonthlySales = createServerFn().handler(async () => {
  return db
    .select({
      month: sql<string>`TO_CHAR(${deliveryOrders.orderDate}::date, 'YYYY-MM')`,
      total: sum(deliveryOrders.totalAmount),
      count: sql<number>`COUNT(*)`,
    })
    .from(deliveryOrders)
    .where(eq(deliveryOrders.status, "delivered"))
    .groupBy(sql`TO_CHAR(${deliveryOrders.orderDate}::date, 'YYYY-MM')`)
    .orderBy(sql`TO_CHAR(${deliveryOrders.orderDate}::date, 'YYYY-MM')`);
});
