import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { products } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getProducts = createServerFn().handler(async () => {
  return db.select().from(products).orderBy(products.name);
});

export const createProduct = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string; scientificName?: string; dosageForm: string;
    strength?: string; unit?: string; sellingPrice?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [p] = await db.insert(products).values(data).returning();
    return p;
  });

export const updateProduct = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; name?: string; scientificName?: string; dosageForm?: string;
    strength?: string; unit?: string; sellingPrice?: string; status?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [p] = await db.update(products).set(rest).where(eq(products.id, id)).returning();
    return p;
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(products).where(eq(products.id, data.id));
    return { success: true };
  });
