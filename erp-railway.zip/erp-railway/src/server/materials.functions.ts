import { createServerFn } from "@tanstack/react-start";
import { eq, desc, sql } from "drizzle-orm";
import { db } from "../../db/index.js";
import { materials, materialReceipts, productBOM, products } from "../../db/schema.js";

// ---- المواد ----

export const getMaterials = createServerFn().handler(async () => {
  return db.select().from(materials).orderBy(materials.materialType, materials.name);
});

export const createMaterial = createServerFn({ method: "POST" })
  .inputValidator((d: {
    name: string;
    materialType: string;
    unit: string;
    unitCost?: string;
    reorderLevel?: string;
    supplier?: string;
    notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    await db.insert(materials).values(data);
  });

export const updateMaterial = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number;
    name?: string;
    unit?: string;
    unitCost?: string;
    reorderLevel?: string;
    supplier?: string;
    status?: string;
    notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    await db.update(materials).set(rest).where(eq(materials.id, id));
  });

export const deleteMaterial = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(materials).where(eq(materials.id, data.id));
  });

// ---- استلام المواد ----

export const getMaterialReceipts = createServerFn().handler(async () => {
  return db
    .select({
      id: materialReceipts.id,
      materialId: materialReceipts.materialId,
      quantityReceived: materialReceipts.quantityReceived,
      batchNumber: materialReceipts.batchNumber,
      expiryDate: materialReceipts.expiryDate,
      receiptDate: materialReceipts.receiptDate,
      unitCost: materialReceipts.unitCost,
      supplier: materialReceipts.supplier,
      invoiceNumber: materialReceipts.invoiceNumber,
      notes: materialReceipts.notes,
      createdAt: materialReceipts.createdAt,
      materialName: materials.name,
      materialUnit: materials.unit,
      materialType: materials.materialType,
    })
    .from(materialReceipts)
    .leftJoin(materials, eq(materialReceipts.materialId, materials.id))
    .orderBy(desc(materialReceipts.createdAt));
});

export const createMaterialReceipt = createServerFn({ method: "POST" })
  .inputValidator((d: {
    materialId: number;
    quantityReceived: string;
    batchNumber?: string;
    expiryDate?: string;
    receiptDate?: string;
    unitCost?: string;
    supplier?: string;
    invoiceNumber?: string;
    notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    await db.insert(materialReceipts).values({
      materialId: data.materialId,
      quantityReceived: data.quantityReceived,
      batchNumber: data.batchNumber,
      expiryDate: data.expiryDate,
      receiptDate: data.receiptDate,
      unitCost: data.unitCost,
      supplier: data.supplier,
      invoiceNumber: data.invoiceNumber,
      notes: data.notes,
    });
    // تراكم المخزون
    await db.update(materials)
      .set({ currentStock: sql`COALESCE(${materials.currentStock}, 0) + ${data.quantityReceived}` })
      .where(eq(materials.id, data.materialId));
    // تحديث سعر الوحدة إذا تم تحديده
    if (data.unitCost) {
      await db.update(materials)
        .set({ unitCost: data.unitCost })
        .where(eq(materials.id, data.materialId));
    }
  });

// ---- قائمة مكونات المنتج (BOM) ----

export const getProductBOM = createServerFn()
  .inputValidator((d: { productId: number }) => d)
  .handler(async ({ data }) => {
    return db
      .select({
        id: productBOM.id,
        productId: productBOM.productId,
        materialId: productBOM.materialId,
        quantityPerUnit: productBOM.quantityPerUnit,
        notes: productBOM.notes,
        materialName: materials.name,
        materialUnit: materials.unit,
        materialType: materials.materialType,
        materialUnitCost: materials.unitCost,
        materialCurrentStock: materials.currentStock,
      })
      .from(productBOM)
      .leftJoin(materials, eq(productBOM.materialId, materials.id))
      .where(eq(productBOM.productId, data.productId))
      .orderBy(materials.materialType, materials.name);
  });

export const getAllProductBOM = createServerFn().handler(async () => {
  return db
    .select({
      id: productBOM.id,
      productId: productBOM.productId,
      materialId: productBOM.materialId,
      quantityPerUnit: productBOM.quantityPerUnit,
      notes: productBOM.notes,
      materialName: materials.name,
      materialUnit: materials.unit,
      materialType: materials.materialType,
      materialUnitCost: materials.unitCost,
      productName: products.name,
    })
    .from(productBOM)
    .leftJoin(materials, eq(productBOM.materialId, materials.id))
    .leftJoin(products, eq(productBOM.productId, products.id))
    .orderBy(products.name, materials.materialType, materials.name);
});

export const addProductBOMItem = createServerFn({ method: "POST" })
  .inputValidator((d: {
    productId: number;
    materialId: number;
    quantityPerUnit: string;
    notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    await db.insert(productBOM).values(data);
  });

export const updateProductBOMItem = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number;
    quantityPerUnit?: string;
    notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    await db.update(productBOM).set(rest).where(eq(productBOM.id, id));
  });

export const deleteProductBOMItem = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(productBOM).where(eq(productBOM.id, data.id));
  });
