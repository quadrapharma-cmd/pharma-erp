import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { deliveryOrders, deliveryOrderItems, distributors, products } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getDeliveryOrders = createServerFn().handler(async () => {
  return db
    .select({
      id: deliveryOrders.id,
      orderNumber: deliveryOrders.orderNumber,
      distributorId: deliveryOrders.distributorId,
      distributorName: distributors.name,
      orderDate: deliveryOrders.orderDate,
      status: deliveryOrders.status,
      totalAmount: deliveryOrders.totalAmount,
      notes: deliveryOrders.notes,
      createdAt: deliveryOrders.createdAt,
    })
    .from(deliveryOrders)
    .innerJoin(distributors, eq(deliveryOrders.distributorId, distributors.id))
    .orderBy(deliveryOrders.createdAt);
});

export const createDeliveryOrder = createServerFn({ method: "POST" })
  .inputValidator((d: {
    distributorId: number; orderNumber?: string; orderDate?: string;
    status?: string; totalAmount?: string; notes?: string;
    items: { productId: number; quantity: number; unitPrice: string }[];
  }) => d)
  .handler(async ({ data }) => {
    const { items, ...orderData } = data;
    const [order] = await db.insert(deliveryOrders).values(orderData).returning();
    if (items?.length) {
      await db.insert(deliveryOrderItems).values(
        items.map(item => ({
          deliveryOrderId: order.id,
          productId: item.productId,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: String(Number(item.unitPrice) * item.quantity),
        }))
      );
    }
    return order;
  });

export const updateDeliveryStatus = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number; status: string }) => d)
  .handler(async ({ data }) => {
    const [o] = await db.update(deliveryOrders).set({ status: data.status })
      .where(eq(deliveryOrders.id, data.id)).returning();
    return o;
  });

export const deleteDeliveryOrder = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(deliveryOrderItems).where(eq(deliveryOrderItems.deliveryOrderId, data.id));
    await db.delete(deliveryOrders).where(eq(deliveryOrders.id, data.id));
    return { success: true };
  });

export const getDeliveryItems = createServerFn({ method: "GET" })
  .inputValidator((d: { orderId: number }) => d)
  .handler(async ({ data }) => {
    return db
      .select({
        id: deliveryOrderItems.id,
        productId: deliveryOrderItems.productId,
        productName: products.name,
        quantity: deliveryOrderItems.quantity,
        unitPrice: deliveryOrderItems.unitPrice,
        totalPrice: deliveryOrderItems.totalPrice,
      })
      .from(deliveryOrderItems)
      .innerJoin(products, eq(deliveryOrderItems.productId, products.id))
      .where(eq(deliveryOrderItems.deliveryOrderId, data.orderId));
  });
