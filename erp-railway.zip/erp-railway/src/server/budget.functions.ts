import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { budgetLines } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getBudgetLines = createServerFn().handler(async () => {
  return db.select().from(budgetLines).orderBy(budgetLines.year, budgetLines.month);
});

export const createBudgetLine = createServerFn({ method: "POST" })
  .inputValidator((d: {
    year: number; month?: number; department?: string;
    category: string; description?: string; budgetedAmount: string;
  }) => d)
  .handler(async ({ data }) => {
    const [b] = await db.insert(budgetLines).values(data).returning();
    return b;
  });

export const updateBudgetLine = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; year?: number; month?: number; department?: string;
    category?: string; description?: string; budgetedAmount?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [b] = await db.update(budgetLines).set(rest).where(eq(budgetLines.id, id)).returning();
    return b;
  });

export const deleteBudgetLine = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(budgetLines).where(eq(budgetLines.id, data.id));
    return { success: true };
  });
