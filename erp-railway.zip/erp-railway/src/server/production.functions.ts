import { createServerFn } from "@tanstack/react-start";
import { db } from "../../db/index.js";
import { productionOrders, products, cmos } from "../../db/schema.js";
import { eq } from "drizzle-orm";

export const getProductionOrders = createServerFn().handler(async () => {
  return db
    .select({
      id: productionOrders.id,
      orderNumber: productionOrders.orderNumber,
      productId: productionOrders.productId,
      productName: products.name,
      cmoId: productionOrders.cmoId,
      cmoName: cmos.name,
      quantity: productionOrders.quantity,
      unitCost: productionOrders.unitCost,
      totalCost: productionOrders.totalCost,
      orderDate: productionOrders.orderDate,
      expectedDate: productionOrders.expectedDate,
      status: productionOrders.status,
      notes: productionOrders.notes,
      createdAt: productionOrders.createdAt,
    })
    .from(productionOrders)
    .innerJoin(products, eq(productionOrders.productId, products.id))
    .innerJoin(cmos, eq(productionOrders.cmoId, cmos.id))
    .orderBy(productionOrders.createdAt);
});

export const createProductionOrder = createServerFn({ method: "POST" })
  .inputValidator((d: {
    productId: number; cmoId: number; orderNumber?: string;
    quantity: number; unitCost?: string; totalCost?: string;
    orderDate?: string; expectedDate?: string; status?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const [o] = await db.insert(productionOrders).values(data).returning();
    return o;
  });

export const updateProductionOrder = createServerFn({ method: "POST" })
  .inputValidator((d: {
    id: number; status?: string; quantity?: number; unitCost?: string;
    totalCost?: string; expectedDate?: string; notes?: string;
  }) => d)
  .handler(async ({ data }) => {
    const { id, ...rest } = data;
    const [o] = await db.update(productionOrders).set(rest).where(eq(productionOrders.id, id)).returning();
    return o;
  });

export const deleteProductionOrder = createServerFn({ method: "POST" })
  .inputValidator((d: { id: number }) => d)
  .handler(async ({ data }) => {
    await db.delete(productionOrders).where(eq(productionOrders.id, data.id));
    return { success: true };
  });
