import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Btn, Table, Badge } from '../../components/Layout'
import { getCmos, createCmo, updateCmo, deleteCmo } from '../../server/cmos.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/cmos/')({
  loader: () => getCmos(),
  component: CmosPage,
})

function CmosPage() {
  const cmos = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof cmos[0] | null>(null)
  const [form, setForm] = useState({ name: '', address: '', contactPerson: '', phone: '', email: '', licenseNumber: '', status: 'active' })
  const [saving, setSaving] = useState(false)

  function openAdd() { setEditing(null); setForm({ name: '', address: '', contactPerson: '', phone: '', email: '', licenseNumber: '', status: 'active' }); setOpen(true) }
  function openEdit(c: typeof cmos[0]) { setEditing(c); setForm({ name: c.name, address: c.address ?? '', contactPerson: c.contactPerson ?? '', phone: c.phone ?? '', email: c.email ?? '', licenseNumber: c.licenseNumber ?? '', status: c.status ?? 'active' }); setOpen(true) }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateCmo({ data: { id: editing.id, ...form } })
      else await createCmo({ data: form })
      setOpen(false)
      navigate({ to: '/cmos' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد من الحذف؟')) return
    await deleteCmo({ data: { id } })
    navigate({ to: '/cmos' })
  }

  return (
    <Layout>
      <PageHeader title="إدارة المصانع (CMOs)" subtitle={`${cmos.length} مصنع`} action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> إضافة مصنع</span></Btn>} />
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['اسم المصنع', 'المسؤول', 'الهاتف', 'البريد', 'رقم الترخيص', 'الحالة', 'إجراءات']} empty={cmos.length === 0}>
            {cmos.map(c => (
              <tr key={c.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900">{c.name}</td>
                <td className="py-3 px-4 text-gray-600">{c.contactPerson ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{c.phone ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{c.email ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{c.licenseNumber ?? '-'}</td>
                <td className="py-3 px-4"><Badge status={c.status ?? 'active'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(c)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(c.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل مصنع' : 'إضافة مصنع جديد'}>
        <div className="space-y-4">
          <Input label="اسم المصنع *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
          <Input label="العنوان" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
          <Input label="المسؤول" value={form.contactPerson} onChange={e => setForm(f => ({ ...f, contactPerson: e.target.value }))} />
          <Input label="الهاتف" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
          <Input label="البريد الإلكتروني" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          <Input label="رقم الترخيص" value={form.licenseNumber} onChange={e => setForm(f => ({ ...f, licenseNumber: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </Select>
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.name}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
