import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, StatCard, fmt } from '../../components/Layout'
import { getCampaigns, createCampaign, updateCampaign, deleteCampaign, getSalesTargets, createSalesTarget, deleteSalesTarget } from '../../server/marketing.functions'
import { getProducts } from '../../server/products.functions'
import { getDistributors } from '../../server/distributors.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/marketing/')({
  loader: async () => {
    const [campaigns, targets, products, distributors] = await Promise.all([
      getCampaigns(), getSalesTargets(), getProducts(), getDistributors()
    ])
    return { campaigns, targets, products, distributors }
  },
  component: MarketingPage,
})

const MONTHS = ['يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']

function MarketingPage() {
  const { campaigns, targets, products, distributors } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [tab, setTab] = useState<'campaigns' | 'targets'>('campaigns')
  const [openCampaign, setOpenCampaign] = useState(false)
  const [openTarget, setOpenTarget] = useState(false)
  const [editing, setEditing] = useState<typeof campaigns[0] | null>(null)
  const [campForm, setCampForm] = useState({ name: '', productId: 0, startDate: '', endDate: '', budget: '', actualSpend: '', status: 'active', notes: '' })
  const [targetForm, setTargetForm] = useState({ productId: 0, distributorId: 0, year: new Date().getFullYear(), month: 0, targetQuantity: 0, targetAmount: '' })
  const [saving, setSaving] = useState(false)

  const totalBudget = campaigns.reduce((s, c) => s + Number(c.budget ?? 0), 0)
  const totalSpend = campaigns.reduce((s, c) => s + Number(c.actualSpend ?? 0), 0)

  function openAddCampaign() { setEditing(null); setCampForm({ name: '', productId: 0, startDate: '', endDate: '', budget: '', actualSpend: '', status: 'active', notes: '' }); setOpenCampaign(true) }
  function openEditCampaign(c: typeof campaigns[0]) {
    setEditing(c)
    setCampForm({ name: c.name, productId: c.productId ?? 0, startDate: c.startDate ?? '', endDate: c.endDate ?? '', budget: c.budget ?? '', actualSpend: c.actualSpend ?? '', status: c.status ?? 'active', notes: c.notes ?? '' })
    setOpenCampaign(true)
  }

  async function handleSaveCampaign() {
    setSaving(true)
    try {
      const data = { ...campForm, productId: campForm.productId || undefined }
      if (editing) await updateCampaign({ data: { id: editing.id, ...data } })
      else await createCampaign({ data })
      setOpenCampaign(false)
      navigate({ to: '/marketing' })
    } finally { setSaving(false) }
  }

  async function handleDeleteCampaign(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteCampaign({ data: { id } })
    navigate({ to: '/marketing' })
  }

  async function handleSaveTarget() {
    setSaving(true)
    try {
      await createSalesTarget({ data: { ...targetForm, productId: targetForm.productId || undefined, distributorId: targetForm.distributorId || undefined, month: targetForm.month || undefined } })
      setOpenTarget(false)
      navigate({ to: '/marketing' })
    } finally { setSaving(false) }
  }

  async function handleDeleteTarget(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteSalesTarget({ data: { id } })
    navigate({ to: '/marketing' })
  }

  return (
    <Layout>
      <PageHeader title="الدعاية والمبيعات" subtitle="حملات التسويق وأهداف المبيعات" action={
        <div className="flex gap-2">
          {tab === 'campaigns' && <Btn onClick={openAddCampaign}><span className="flex items-center gap-2"><Plus size={16} /> حملة جديدة</span></Btn>}
          {tab === 'targets' && <Btn onClick={() => setOpenTarget(true)}><span className="flex items-center gap-2"><Plus size={16} /> هدف جديد</span></Btn>}
        </div>
      } />
      <div className="p-6">
        {tab === 'campaigns' && (
          <div className="grid grid-cols-3 gap-4 mb-6">
            <StatCard title="إجمالي ميزانية التسويق" value={`${fmt(totalBudget)} ج.م`} color="text-blue-600" />
            <StatCard title="الإنفاق الفعلي" value={`${fmt(totalSpend)} ج.م`} color="text-red-600" />
            <StatCard title="المتبقي" value={`${fmt(totalBudget - totalSpend)} ج.م`} color="text-emerald-600" />
          </div>
        )}

        <div className="flex gap-2 mb-4">
          <button onClick={() => setTab('campaigns')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'campaigns' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>حملات الدعاية</button>
          <button onClick={() => setTab('targets')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'targets' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>أهداف المبيعات</button>
        </div>

        {tab === 'campaigns' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['اسم الحملة', 'المنتج', 'البداية', 'النهاية', 'الميزانية', 'الإنفاق الفعلي', 'الحالة', 'إجراءات']} empty={campaigns.length === 0}>
              {campaigns.map(c => (
                <tr key={c.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{c.name}</td>
                  <td className="py-3 px-4 text-gray-600">{c.productName ?? 'عام'}</td>
                  <td className="py-3 px-4 text-gray-600 text-sm">{c.startDate ?? '-'}</td>
                  <td className="py-3 px-4 text-gray-600 text-sm">{c.endDate ?? '-'}</td>
                  <td className="py-3 px-4 text-blue-700 font-medium">{c.budget ? `${fmt(c.budget)} ج.م` : '-'}</td>
                  <td className="py-3 px-4 text-red-700 font-medium">{c.actualSpend ? `${fmt(c.actualSpend)} ج.م` : '-'}</td>
                  <td className="py-3 px-4"><Badge status={c.status ?? 'active'} /></td>
                  <td className="py-3 px-4">
                    <div className="flex gap-2">
                      <button onClick={() => openEditCampaign(c)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                      <button onClick={() => handleDeleteCampaign(c.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </Table>
          </div>
        )}

        {tab === 'targets' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['المنتج', 'الموزع', 'السنة', 'الشهر', 'الكمية المستهدفة', 'المبلغ المستهدف', 'إجراءات']} empty={targets.length === 0}>
              {targets.map(t => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{t.productName ?? 'كل المنتجات'}</td>
                  <td className="py-3 px-4 text-gray-600">{t.distributorName ?? 'كل الموزعين'}</td>
                  <td className="py-3 px-4 text-gray-600">{t.year}</td>
                  <td className="py-3 px-4 text-gray-600">{t.month ? MONTHS[t.month - 1] : 'سنوي'}</td>
                  <td className="py-3 px-4 font-medium text-gray-700">{t.targetQuantity?.toLocaleString() ?? '-'}</td>
                  <td className="py-3 px-4 text-emerald-700 font-medium">{t.targetAmount ? `${fmt(t.targetAmount)} ج.م` : '-'}</td>
                  <td className="py-3 px-4"><button onClick={() => handleDeleteTarget(t.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button></td>
                </tr>
              ))}
            </Table>
          </div>
        )}
      </div>

      <Modal open={openCampaign} onClose={() => setOpenCampaign(false)} title={editing ? 'تعديل حملة' : 'حملة دعائية جديدة'}>
        <div className="space-y-4">
          <Input label="اسم الحملة *" value={campForm.name} onChange={e => setCampForm(f => ({ ...f, name: e.target.value }))} required />
          <Select label="المنتج (اختياري)" value={campForm.productId} onChange={e => setCampForm(f => ({ ...f, productId: Number(e.target.value) }))}>
            <option value={0}>حملة عامة</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          <Input label="تاريخ البداية" type="date" value={campForm.startDate} onChange={e => setCampForm(f => ({ ...f, startDate: e.target.value }))} />
          <Input label="تاريخ النهاية" type="date" value={campForm.endDate} onChange={e => setCampForm(f => ({ ...f, endDate: e.target.value }))} />
          <Input label="ميزانية الحملة (ج.م)" type="number" step="0.01" value={campForm.budget} onChange={e => setCampForm(f => ({ ...f, budget: e.target.value }))} />
          <Input label="الإنفاق الفعلي (ج.م)" type="number" step="0.01" value={campForm.actualSpend} onChange={e => setCampForm(f => ({ ...f, actualSpend: e.target.value }))} />
          <Select label="الحالة" value={campForm.status} onChange={e => setCampForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشطة</option>
            <option value="inactive">منتهية</option>
          </Select>
          <Textarea label="ملاحظات" value={campForm.notes} onChange={e => setCampForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSaveCampaign} disabled={saving || !campForm.name}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpenCampaign(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>

      <Modal open={openTarget} onClose={() => setOpenTarget(false)} title="هدف مبيعات جديد">
        <div className="space-y-4">
          <Select label="المنتج" value={targetForm.productId} onChange={e => setTargetForm(f => ({ ...f, productId: Number(e.target.value) }))}>
            <option value={0}>كل المنتجات</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          <Select label="الموزع" value={targetForm.distributorId} onChange={e => setTargetForm(f => ({ ...f, distributorId: Number(e.target.value) }))}>
            <option value={0}>كل الموزعين</option>
            {distributors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
          <Input label="السنة *" type="number" value={targetForm.year} onChange={e => setTargetForm(f => ({ ...f, year: Number(e.target.value) }))} />
          <Select label="الشهر" value={targetForm.month} onChange={e => setTargetForm(f => ({ ...f, month: Number(e.target.value) }))}>
            <option value={0}>سنوي</option>
            {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
          </Select>
          <Input label="الكمية المستهدفة" type="number" value={targetForm.targetQuantity} onChange={e => setTargetForm(f => ({ ...f, targetQuantity: Number(e.target.value) }))} />
          <Input label="المبلغ المستهدف (ج.م)" type="number" step="0.01" value={targetForm.targetAmount} onChange={e => setTargetForm(f => ({ ...f, targetAmount: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSaveTarget} disabled={saving}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpenTarget(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
