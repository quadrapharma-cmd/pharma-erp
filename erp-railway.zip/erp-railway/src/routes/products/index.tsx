import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, fmt } from '../../components/Layout'
import { getProducts, createProduct, updateProduct, deleteProduct } from '../../server/products.functions'
import { getMaterials, getProductBOM, addProductBOMItem, updateProductBOMItem, deleteProductBOMItem } from '../../server/materials.functions'
import { Plus, Pencil, Trash2, FlaskConical, ChevronDown } from 'lucide-react'

export const Route = createFileRoute('/products/')({
  loader: async () => ({
    products: await getProducts(),
    materials: await getMaterials(),
  }),
  component: ProductsPage,
})

type Product = Awaited<ReturnType<typeof getProducts>>[0]
type Material = Awaited<ReturnType<typeof getMaterials>>[0]
type BOMItem = Awaited<ReturnType<typeof getProductBOM>>

const FORMS = ['شراب', 'أقراص', 'كبسولات', 'حقن', 'مرهم', 'قطرة', 'تحاميل', 'بودرة', 'أمبولات']

function ProductsPage() {
  const { products, materials } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)
  const [form, setForm] = useState({ name: '', scientificName: '', dosageForm: '', strength: '', unit: 'علبة', sellingPrice: '', status: 'active' })
  const [saving, setSaving] = useState(false)

  // BOM modal state
  const [bomProduct, setBomProduct] = useState<Product | null>(null)
  const [bomItems, setBomItems] = useState<BOMItem>([])
  const [bomLoading, setBomLoading] = useState(false)
  const [bomAddForm, setBomAddForm] = useState({ materialId: '', quantityPerUnit: '', notes: '' })
  const [bomSaving, setBomSaving] = useState(false)
  const [editingBOMItem, setEditingBOMItem] = useState<BOMItem[0] | null>(null)

  function openAdd() { setEditing(null); setForm({ name: '', scientificName: '', dosageForm: '', strength: '', unit: 'علبة', sellingPrice: '', status: 'active' }); setOpen(true) }
  function openEdit(p: Product) { setEditing(p); setForm({ name: p.name, scientificName: p.scientificName ?? '', dosageForm: p.dosageForm, strength: p.strength ?? '', unit: p.unit ?? 'علبة', sellingPrice: p.sellingPrice ?? '', status: p.status ?? 'active' }); setOpen(true) }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateProduct({ data: { id: editing.id, ...form } })
      else await createProduct({ data: form })
      setOpen(false)
      navigate({ to: '/products' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد من الحذف؟')) return
    await deleteProduct({ data: { id } })
    navigate({ to: '/products' })
  }

  async function openBOM(p: Product) {
    setBomProduct(p)
    setBomLoading(true)
    setBomAddForm({ materialId: '', quantityPerUnit: '', notes: '' })
    setEditingBOMItem(null)
    try {
      const items = await getProductBOM({ data: { productId: p.id } })
      setBomItems(items)
    } finally { setBomLoading(false) }
  }

  async function handleAddBOMItem() {
    if (!bomProduct || !bomAddForm.materialId || !bomAddForm.quantityPerUnit) return
    setBomSaving(true)
    try {
      await addProductBOMItem({ data: { productId: bomProduct.id, materialId: Number(bomAddForm.materialId), quantityPerUnit: bomAddForm.quantityPerUnit, notes: bomAddForm.notes } })
      const items = await getProductBOM({ data: { productId: bomProduct.id } })
      setBomItems(items)
      setBomAddForm({ materialId: '', quantityPerUnit: '', notes: '' })
    } finally { setBomSaving(false) }
  }

  async function handleUpdateBOMItem() {
    if (!editingBOMItem) return
    setBomSaving(true)
    try {
      await updateProductBOMItem({ data: { id: editingBOMItem.id, quantityPerUnit: editingBOMItem.quantityPerUnit ?? '', notes: editingBOMItem.notes ?? '' } })
      const items = await getProductBOM({ data: { productId: bomProduct!.id } })
      setBomItems(items)
      setEditingBOMItem(null)
    } finally { setBomSaving(false) }
  }

  async function handleDeleteBOMItem(id: number) {
    if (!confirm('إزالة هذه المادة من القائمة؟')) return
    await deleteProductBOMItem({ data: { id } })
    const items = await getProductBOM({ data: { productId: bomProduct!.id } })
    setBomItems(items)
  }

  // Calculate total material cost per unit
  const totalMaterialCost = bomItems.reduce((sum, item) => {
    const qty = Number(item.quantityPerUnit ?? 0)
    const cost = Number(item.materialUnitCost ?? 0)
    return sum + qty * cost
  }, 0)

  const rawMaterials = materials.filter(m => m.materialType === 'raw_material')
  const packagingMaterials = materials.filter(m => m.materialType === 'packaging')
  const usedMaterialIds = new Set(bomItems.map(b => b.materialId))

  return (
    <Layout>
      <PageHeader title="إدارة المنتجات" subtitle={`${products.length} منتج`} action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> إضافة منتج</span></Btn>} />
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['اسم المنتج', 'الاسم العلمي', 'الشكل الدوائي', 'التركيز', 'الوحدة', 'سعر البيع', 'تكلفة المواد/وحدة', 'الحالة', 'إجراءات']} empty={products.length === 0}>
            {products.map(p => (
              <tr key={p.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900">{p.name}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{p.scientificName ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{p.dosageForm}</td>
                <td className="py-3 px-4 text-gray-600">{p.strength ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{p.unit}</td>
                <td className="py-3 px-4 font-medium">{p.sellingPrice ? `${fmt(p.sellingPrice)} ج.م` : '-'}</td>
                <td className="py-3 px-4">
                  <button
                    onClick={() => openBOM(p)}
                    className="flex items-center gap-1.5 text-blue-600 hover:text-blue-800 text-sm font-medium"
                    title="عرض وتعديل قائمة المكونات"
                  >
                    <FlaskConical size={14} />
                    <span>قائمة المواد</span>
                    <ChevronDown size={12} />
                  </button>
                </td>
                <td className="py-3 px-4"><Badge status={p.status ?? 'active'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(p)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(p.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      {/* Product Add/Edit Modal */}
      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل منتج' : 'إضافة منتج جديد'}>
        <div className="space-y-4">
          <Input label="اسم المنتج *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
          <Input label="الاسم العلمي" value={form.scientificName} onChange={e => setForm(f => ({ ...f, scientificName: e.target.value }))} />
          <Select label="الشكل الدوائي *" value={form.dosageForm} onChange={e => setForm(f => ({ ...f, dosageForm: e.target.value }))}>
            <option value="">اختر...</option>
            {FORMS.map(f => <option key={f} value={f}>{f}</option>)}
          </Select>
          <Input label="التركيز / القوة" value={form.strength} onChange={e => setForm(f => ({ ...f, strength: e.target.value }))} placeholder="مثال: 500mg" />
          <Input label="الوحدة" value={form.unit} onChange={e => setForm(f => ({ ...f, unit: e.target.value }))} />
          <Input label="سعر البيع (ج.م)" type="number" value={form.sellingPrice} onChange={e => setForm(f => ({ ...f, sellingPrice: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </Select>
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.name || !form.dosageForm}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>

      {/* BOM Modal */}
      <Modal open={!!bomProduct} onClose={() => { setBomProduct(null); setBomItems([]) }} title={`قائمة مكونات المنتج — ${bomProduct?.name ?? ''}`}>
        <div className="space-y-4">
          {/* Cost Summary */}
          {bomItems.length > 0 && (
            <div className="bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex items-center justify-between">
              <span className="text-sm font-medium text-emerald-800">إجمالي تكلفة المواد للوحدة الواحدة</span>
              <span className="text-lg font-bold text-emerald-700">{fmt(totalMaterialCost)} ج.م</span>
            </div>
          )}

          {/* BOM Items List */}
          {bomLoading ? (
            <p className="text-center text-gray-400 py-4">جاري التحميل...</p>
          ) : (
            <div className="border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">المادة</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">النوع</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">الكمية/وحدة</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">سعر الوحدة</th>
                    <th className="text-right py-2 px-3 font-semibold text-gray-600">التكلفة</th>
                    <th className="py-2 px-3"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {bomItems.length === 0 ? (
                    <tr><td colSpan={6} className="py-6 text-center text-gray-400">لم يتم تحديد مكونات بعد</td></tr>
                  ) : bomItems.map(item => (
                    <tr key={item.id} className="hover:bg-gray-50">
                      <td className="py-2 px-3 font-medium text-gray-900">
                        {editingBOMItem?.id === item.id ? (
                          <span className="text-gray-500 text-xs">{item.materialName}</span>
                        ) : item.materialName}
                      </td>
                      <td className="py-2 px-3">
                        <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${item.materialType === 'raw_material' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                          {item.materialType === 'raw_material' ? 'خام' : 'تغليف'}
                        </span>
                      </td>
                      <td className="py-2 px-3">
                        {editingBOMItem?.id === item.id ? (
                          <input
                            type="number" step="0.0001"
                            value={editingBOMItem.quantityPerUnit ?? ''}
                            onChange={e => setEditingBOMItem(prev => prev ? { ...prev, quantityPerUnit: e.target.value } : null)}
                            className="w-24 border border-gray-300 rounded px-2 py-1 text-sm focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        ) : (
                          <span>{fmt(item.quantityPerUnit)} {item.materialUnit}</span>
                        )}
                      </td>
                      <td className="py-2 px-3 text-gray-600">{item.materialUnitCost ? `${fmt(item.materialUnitCost)} ج.م` : '-'}</td>
                      <td className="py-2 px-3 font-medium text-gray-800">
                        {item.materialUnitCost ? `${fmt(Number(item.quantityPerUnit ?? 0) * Number(item.materialUnitCost ?? 0))} ج.م` : '-'}
                      </td>
                      <td className="py-2 px-3">
                        <div className="flex gap-1">
                          {editingBOMItem?.id === item.id ? (
                            <>
                              <button onClick={handleUpdateBOMItem} disabled={bomSaving} className="text-emerald-600 hover:text-emerald-800 text-xs font-medium">حفظ</button>
                              <button onClick={() => setEditingBOMItem(null)} className="text-gray-500 hover:text-gray-700 text-xs">إلغاء</button>
                            </>
                          ) : (
                            <>
                              <button onClick={() => setEditingBOMItem(item)} className="text-blue-600 hover:text-blue-800"><Pencil size={13} /></button>
                              <button onClick={() => handleDeleteBOMItem(item.id)} className="text-red-600 hover:text-red-800"><Trash2 size={13} /></button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Add BOM Item */}
          <div className="border-t pt-4">
            <p className="text-sm font-semibold text-gray-700 mb-3">إضافة مادة للقائمة</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <Select label="المادة *" value={bomAddForm.materialId} onChange={e => setBomAddForm(f => ({ ...f, materialId: e.target.value }))}>
                  <option value="">اختر مادة...</option>
                  <optgroup label="مواد خام">
                    {rawMaterials.filter(m => !usedMaterialIds.has(m.id)).map(m => (
                      <option key={m.id} value={m.id}>{m.name} ({m.unit}) — {m.unitCost ? `${fmt(m.unitCost)} ج.م` : 'بدون سعر'}</option>
                    ))}
                  </optgroup>
                  <optgroup label="مواد التغليف">
                    {packagingMaterials.filter(m => !usedMaterialIds.has(m.id)).map(m => (
                      <option key={m.id} value={m.id}>{m.name} ({m.unit}) — {m.unitCost ? `${fmt(m.unitCost)} ج.م` : 'بدون سعر'}</option>
                    ))}
                  </optgroup>
                </Select>
              </div>
              <Input label="الكمية لكل وحدة منتج *" type="number" step="0.0001" value={bomAddForm.quantityPerUnit} onChange={e => setBomAddForm(f => ({ ...f, quantityPerUnit: e.target.value }))} placeholder="0.0000" />
              <Input label="ملاحظات" value={bomAddForm.notes} onChange={e => setBomAddForm(f => ({ ...f, notes: e.target.value }))} />
            </div>
            <div className="mt-3">
              <Btn onClick={handleAddBOMItem} disabled={bomSaving || !bomAddForm.materialId || !bomAddForm.quantityPerUnit}>
                {bomSaving ? 'جاري الإضافة...' : 'إضافة للقائمة'}
              </Btn>
            </div>
          </div>

          {/* If no materials defined yet */}
          {materials.length === 0 && (
            <p className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded p-3">
              لم يتم تعريف أي مواد بعد. يرجى إضافة مواد من صفحة <strong>المواد الخام والتغليف</strong> أولاً.
            </p>
          )}
        </div>
      </Modal>
    </Layout>
  )
}
