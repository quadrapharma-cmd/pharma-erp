import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Btn, Table, Badge, fmt } from '../../components/Layout'
import { getDistributors, createDistributor, updateDistributor, deleteDistributor } from '../../server/distributors.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/distributors/')({
  loader: () => getDistributors(),
  component: DistributorsPage,
})

function DistributorsPage() {
  const distributors = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof distributors[0] | null>(null)
  const [form, setForm] = useState({ name: '', address: '', contactPerson: '', phone: '', email: '', creditLimit: '', status: 'active' })
  const [saving, setSaving] = useState(false)

  function openAdd() { setEditing(null); setForm({ name: '', address: '', contactPerson: '', phone: '', email: '', creditLimit: '', status: 'active' }); setOpen(true) }
  function openEdit(d: typeof distributors[0]) {
    setEditing(d)
    setForm({ name: d.name, address: d.address ?? '', contactPerson: d.contactPerson ?? '', phone: d.phone ?? '', email: d.email ?? '', creditLimit: d.creditLimit ?? '', status: d.status ?? 'active' })
    setOpen(true)
  }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateDistributor({ data: { id: editing.id, ...form } })
      else await createDistributor({ data: form })
      setOpen(false)
      navigate({ to: '/distributors' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteDistributor({ data: { id } })
    navigate({ to: '/distributors' })
  }

  return (
    <Layout>
      <PageHeader title="شركات التوزيع" subtitle={`${distributors.length} موزع`} action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> إضافة موزع</span></Btn>} />
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['اسم الشركة', 'المسؤول', 'الهاتف', 'البريد الإلكتروني', 'حد الائتمان', 'الحالة', 'إجراءات']} empty={distributors.length === 0}>
            {distributors.map(d => (
              <tr key={d.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900">{d.name}</td>
                <td className="py-3 px-4 text-gray-600">{d.contactPerson ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{d.phone ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{d.email ?? '-'}</td>
                <td className="py-3 px-4 font-medium">{d.creditLimit ? `${fmt(d.creditLimit)} ج.م` : '-'}</td>
                <td className="py-3 px-4"><Badge status={d.status ?? 'active'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(d)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(d.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل موزع' : 'إضافة موزع جديد'}>
        <div className="space-y-4">
          <Input label="اسم الشركة *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
          <Input label="العنوان" value={form.address} onChange={e => setForm(f => ({ ...f, address: e.target.value }))} />
          <Input label="المسؤول" value={form.contactPerson} onChange={e => setForm(f => ({ ...f, contactPerson: e.target.value }))} />
          <Input label="الهاتف" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
          <Input label="البريد الإلكتروني" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          <Input label="حد الائتمان (ج.م)" type="number" step="0.01" value={form.creditLimit} onChange={e => setForm(f => ({ ...f, creditLimit: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </Select>
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.name}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
