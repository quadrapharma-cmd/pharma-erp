import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, fmt } from '../../components/Layout'
import { getDeliveryOrders, createDeliveryOrder, updateDeliveryStatus, deleteDeliveryOrder } from '../../server/deliveries.functions'
import { getDistributors } from '../../server/distributors.functions'
import { getProducts } from '../../server/products.functions'
import { Plus, Trash2, CheckCircle } from 'lucide-react'

export const Route = createFileRoute('/deliveries/')({
  loader: async () => {
    const [orders, distributors, products] = await Promise.all([getDeliveryOrders(), getDistributors(), getProducts()])
    return { orders, distributors, products }
  },
  component: DeliveriesPage,
})

type Item = { productId: number; quantity: number; unitPrice: string }

function DeliveriesPage() {
  const { orders, distributors, products } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ distributorId: 0, orderNumber: '', orderDate: new Date().toISOString().slice(0, 10), notes: '' })
  const [items, setItems] = useState<Item[]>([{ productId: 0, quantity: 1, unitPrice: '' }])
  const [saving, setSaving] = useState(false)

  const totalRevenue = orders.filter(o => o.status === 'delivered').reduce((s, o) => s + Number(o.totalAmount ?? 0), 0)

  function addItem() { setItems(i => [...i, { productId: 0, quantity: 1, unitPrice: '' }]) }
  function removeItem(idx: number) { setItems(i => i.filter((_, j) => j !== idx)) }
  function updateItem(idx: number, field: keyof Item, value: string | number) {
    setItems(i => i.map((item, j) => j === idx ? { ...item, [field]: value } : item))
  }

  const totalAmount = items.reduce((s, i) => s + (i.quantity * Number(i.unitPrice || 0)), 0)

  async function handleSave() {
    setSaving(true)
    try {
      await createDeliveryOrder({ data: { ...form, totalAmount: String(totalAmount), items } })
      setOpen(false)
      setItems([{ productId: 0, quantity: 1, unitPrice: '' }])
      navigate({ to: '/deliveries' })
    } finally { setSaving(false) }
  }

  async function markDelivered(id: number) {
    await updateDeliveryStatus({ data: { id, status: 'delivered' } })
    navigate({ to: '/deliveries' })
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteDeliveryOrder({ data: { id } })
    navigate({ to: '/deliveries' })
  }

  return (
    <Layout>
      <PageHeader title="التوريد والمبيعات" subtitle={`إجمالي المبيعات المسلّمة: ${fmt(totalRevenue)} ج.م`} action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus size={16} /> أمر توريد جديد</span></Btn>} />
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['رقم الأمر', 'الموزع', 'التاريخ', 'إجمالي المبلغ', 'الحالة', 'إجراءات']} empty={orders.length === 0}>
            {orders.map(o => (
              <tr key={o.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 text-gray-600 font-mono text-sm">{o.orderNumber ?? `DO-${o.id}`}</td>
                <td className="py-3 px-4 font-medium text-gray-900">{o.distributorName}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{o.orderDate ?? '-'}</td>
                <td className="py-3 px-4 font-bold text-emerald-700">{o.totalAmount ? `${fmt(o.totalAmount)} ج.م` : '-'}</td>
                <td className="py-3 px-4"><Badge status={o.status ?? 'pending'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    {o.status === 'pending' && (
                      <button onClick={() => markDelivered(o.id)} className="text-emerald-600 hover:text-emerald-800" title="تأكيد التسليم">
                        <CheckCircle size={16} />
                      </button>
                    )}
                    <button onClick={() => handleDelete(o.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="أمر توريد جديد">
        <div className="space-y-4">
          <Select label="الموزع *" value={form.distributorId} onChange={e => setForm(f => ({ ...f, distributorId: Number(e.target.value) }))}>
            <option value={0}>اختر موزع...</option>
            {distributors.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </Select>
          <Input label="رقم الأمر" value={form.orderNumber} onChange={e => setForm(f => ({ ...f, orderNumber: e.target.value }))} />
          <Input label="تاريخ الأمر" type="date" value={form.orderDate} onChange={e => setForm(f => ({ ...f, orderDate: e.target.value }))} />

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-sm font-medium text-gray-700">بنود الأمر</label>
              <button onClick={addItem} className="text-xs text-emerald-600 hover:text-emerald-800 font-medium">+ إضافة بند</button>
            </div>
            <div className="space-y-2 border rounded-lg p-3 bg-gray-50">
              {items.map((item, idx) => (
                <div key={idx} className="flex gap-2 items-start">
                  <select className="flex-1 border border-gray-300 rounded px-2 py-1.5 text-sm" value={item.productId} onChange={e => updateItem(idx, 'productId', Number(e.target.value))}>
                    <option value={0}>اختر منتج...</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                  </select>
                  <input type="number" placeholder="الكمية" className="w-20 border border-gray-300 rounded px-2 py-1.5 text-sm" value={item.quantity} onChange={e => updateItem(idx, 'quantity', Number(e.target.value))} />
                  <input type="number" placeholder="السعر" className="w-24 border border-gray-300 rounded px-2 py-1.5 text-sm" value={item.unitPrice} onChange={e => updateItem(idx, 'unitPrice', e.target.value)} />
                  {items.length > 1 && <button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700 mt-1"><Trash2 size={14} /></button>}
                </div>
              ))}
            </div>
            <p className="text-sm font-bold text-emerald-700 mt-2">الإجمالي: {fmt(totalAmount)} ج.م</p>
          </div>

          <Textarea label="ملاحظات" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.distributorId}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
