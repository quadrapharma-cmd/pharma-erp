import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Btn, Table, Badge, StatCard, fmt } from '../../components/Layout'
import { getEmployees, createEmployee, updateEmployee, deleteEmployee } from '../../server/employees.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/employees/')({
  loader: () => getEmployees(),
  component: EmployeesPage,
})

const DEPARTMENTS = ['التصنيع', 'التسجيل الدوائي', 'الحسابات', 'الدعاية والمبيعات', 'الإدارة']

function EmployeesPage() {
  const employees = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof employees[0] | null>(null)
  const [form, setForm] = useState({ name: '', department: '', position: '', salary: '', hireDate: '', status: 'active', phone: '', email: '' })
  const [saving, setSaving] = useState(false)

  const active = employees.filter(e => e.status === 'active')
  const totalSalaries = active.reduce((s, e) => s + Number(e.salary ?? 0), 0)

  function openAdd() { setEditing(null); setForm({ name: '', department: '', position: '', salary: '', hireDate: '', status: 'active', phone: '', email: '' }); setOpen(true) }
  function openEdit(e: typeof employees[0]) {
    setEditing(e)
    setForm({ name: e.name, department: e.department, position: e.position, salary: e.salary ?? '', hireDate: e.hireDate ?? '', status: e.status ?? 'active', phone: e.phone ?? '', email: e.email ?? '' })
    setOpen(true)
  }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateEmployee({ data: { id: editing.id, ...form } })
      else await createEmployee({ data: form })
      setOpen(false)
      navigate({ to: '/employees' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteEmployee({ data: { id } })
    navigate({ to: '/employees' })
  }

  return (
    <Layout>
      <PageHeader title="إدارة الموظفين" subtitle={`${active.length} موظف نشط`} action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> إضافة موظف</span></Btn>} />
      <div className="p-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <StatCard title="إجمالي الموظفين" value={employees.length} sub={`${active.length} نشط`} />
          <StatCard title="إجمالي الرواتب الشهرية" value={`${fmt(totalSalaries)} ج.م`} color="text-red-600" />
          <StatCard title="الرواتب السنوية" value={`${fmt(totalSalaries * 12)} ج.م`} color="text-purple-600" />
        </div>

        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['الاسم', 'القسم', 'المنصب', 'الراتب', 'تاريخ التعيين', 'الهاتف', 'الحالة', 'إجراءات']} empty={employees.length === 0}>
            {employees.map(e => (
              <tr key={e.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900">{e.name}</td>
                <td className="py-3 px-4 text-gray-600">{e.department}</td>
                <td className="py-3 px-4 text-gray-600">{e.position}</td>
                <td className="py-3 px-4 font-medium text-gray-700">{e.salary ? `${fmt(e.salary)} ج.م` : '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{e.hireDate ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{e.phone ?? '-'}</td>
                <td className="py-3 px-4"><Badge status={e.status ?? 'active'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(e)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(e.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل موظف' : 'إضافة موظف جديد'}>
        <div className="space-y-4">
          <Input label="الاسم الكامل *" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} required />
          <Select label="القسم *" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))}>
            <option value="">اختر قسم...</option>
            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
          </Select>
          <Input label="المنصب الوظيفي *" value={form.position} onChange={e => setForm(f => ({ ...f, position: e.target.value }))} required />
          <Input label="الراتب الشهري (ج.م)" type="number" step="0.01" value={form.salary} onChange={e => setForm(f => ({ ...f, salary: e.target.value }))} />
          <Input label="تاريخ التعيين" type="date" value={form.hireDate} onChange={e => setForm(f => ({ ...f, hireDate: e.target.value }))} />
          <Input label="الهاتف" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} />
          <Input label="البريد الإلكتروني" type="email" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </Select>
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.name || !form.department || !form.position}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
