import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, fmt } from '../../components/Layout'
import { getRegistrations, createRegistration, updateRegistration, deleteRegistration } from '../../server/registration.functions'
import { getProducts } from '../../server/products.functions'
import { Plus, Pencil, Trash2, AlertTriangle } from 'lucide-react'

export const Route = createFileRoute('/registration/')({
  loader: async () => {
    const [registrations, products] = await Promise.all([getRegistrations(), getProducts()])
    return { registrations, products }
  },
  component: RegistrationPage,
})

function RegistrationPage() {
  const { registrations, products } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof registrations[0] | null>(null)
  const [form, setForm] = useState({ productId: 0, registrationNumber: '', issueDate: '', expiryDate: '', registrationFee: '', renewalFee: '', status: 'active', notes: '' })
  const [saving, setSaving] = useState(false)

  const today = new Date()
  const expiringSoon = registrations.filter(r => {
    if (!r.expiryDate) return false
    const exp = new Date(r.expiryDate)
    const diff = (exp.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
    return diff <= 90 && diff > 0
  })

  function openAdd() { setEditing(null); setForm({ productId: 0, registrationNumber: '', issueDate: '', expiryDate: '', registrationFee: '', renewalFee: '', status: 'active', notes: '' }); setOpen(true) }
  function openEdit(r: typeof registrations[0]) {
    setEditing(r)
    setForm({ productId: r.productId, registrationNumber: r.registrationNumber ?? '', issueDate: r.issueDate ?? '', expiryDate: r.expiryDate ?? '', registrationFee: r.registrationFee ?? '', renewalFee: r.renewalFee ?? '', status: r.status ?? 'active', notes: r.notes ?? '' })
    setOpen(true)
  }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateRegistration({ data: { id: editing.id, ...form } })
      else await createRegistration({ data: { ...form } })
      setOpen(false)
      navigate({ to: '/registration' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteRegistration({ data: { id } })
    navigate({ to: '/registration' })
  }

  function isExpired(date?: string | null) {
    if (!date) return false
    return new Date(date) < today
  }

  return (
    <Layout>
      <PageHeader title="التسجيل الدوائي" subtitle="تراخيص هيئة الدواء المصرية" action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> تسجيل جديد</span></Btn>} />
      <div className="p-6">
        {expiringSoon.length > 0 && (
          <div className="mb-4 bg-amber-50 border border-amber-300 rounded-xl p-4 flex gap-3">
            <AlertTriangle className="text-amber-600 shrink-0 mt-0.5" size={18} />
            <div>
              <p className="font-semibold text-amber-800">تحذير: تراخيص تنتهي خلال 90 يوم</p>
              <p className="text-sm text-amber-700">{expiringSoon.map(r => r.productName).join(' • ')}</p>
            </div>
          </div>
        )}
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['المنتج', 'رقم التسجيل', 'تاريخ الإصدار', 'تاريخ الانتهاء', 'رسوم التسجيل', 'رسوم التجديد', 'الحالة', 'إجراءات']} empty={registrations.length === 0}>
            {registrations.map(r => (
              <tr key={r.id} className={`hover:bg-gray-50 ${isExpired(r.expiryDate) ? 'bg-red-50' : ''}`}>
                <td className="py-3 px-4 font-medium text-gray-900">{r.productName}</td>
                <td className="py-3 px-4 text-gray-600 font-mono text-sm">{r.registrationNumber ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{r.issueDate ?? '-'}</td>
                <td className={`py-3 px-4 text-sm font-medium ${isExpired(r.expiryDate) ? 'text-red-600' : 'text-gray-600'}`}>{r.expiryDate ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600">{r.registrationFee ? `${fmt(r.registrationFee)} ج.م` : '-'}</td>
                <td className="py-3 px-4 text-gray-600">{r.renewalFee ? `${fmt(r.renewalFee)} ج.م` : '-'}</td>
                <td className="py-3 px-4"><Badge status={isExpired(r.expiryDate) ? 'expired' : (r.status ?? 'active')} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(r)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(r.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل تسجيل' : 'تسجيل دوائي جديد'}>
        <div className="space-y-4">
          {!editing && (
            <Select label="المنتج *" value={form.productId} onChange={e => setForm(f => ({ ...f, productId: Number(e.target.value) }))}>
              <option value={0}>اختر منتج...</option>
              {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          )}
          <Input label="رقم التسجيل" value={form.registrationNumber} onChange={e => setForm(f => ({ ...f, registrationNumber: e.target.value }))} />
          <Input label="تاريخ الإصدار" type="date" value={form.issueDate} onChange={e => setForm(f => ({ ...f, issueDate: e.target.value }))} />
          <Input label="تاريخ الانتهاء" type="date" value={form.expiryDate} onChange={e => setForm(f => ({ ...f, expiryDate: e.target.value }))} />
          <Input label="رسوم التسجيل (ج.م)" type="number" step="0.01" value={form.registrationFee} onChange={e => setForm(f => ({ ...f, registrationFee: e.target.value }))} />
          <Input label="رسوم التجديد (ج.م)" type="number" step="0.01" value={form.renewalFee} onChange={e => setForm(f => ({ ...f, renewalFee: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="pending">قيد الانتظار</option>
            <option value="expired">منتهي</option>
          </Select>
          <Textarea label="ملاحظات" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
