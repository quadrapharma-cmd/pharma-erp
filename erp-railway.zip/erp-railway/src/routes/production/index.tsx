import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, fmt } from '../../components/Layout'
import { getProductionOrders, createProductionOrder, updateProductionOrder, deleteProductionOrder } from '../../server/production.functions'
import { getProducts } from '../../server/products.functions'
import { getCmos } from '../../server/cmos.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/production/')({
  loader: async () => {
    const [orders, products, cmos] = await Promise.all([getProductionOrders(), getProducts(), getCmos()])
    return { orders, products, cmos }
  },
  component: ProductionPage,
})

const STATUSES = [
  { value: 'pending', label: 'قيد الانتظار' },
  { value: 'in_production', label: 'في الإنتاج' },
  { value: 'received', label: 'مستلم' },
  { value: 'cancelled', label: 'ملغي' },
]

function ProductionPage() {
  const { orders, products, cmos } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof orders[0] | null>(null)
  const [form, setForm] = useState({ productId: 0, cmoId: 0, orderNumber: '', quantity: 0, unitCost: '', totalCost: '', orderDate: '', expectedDate: '', status: 'pending', notes: '' })
  const [saving, setSaving] = useState(false)

  function openAdd() { setEditing(null); setForm({ productId: 0, cmoId: 0, orderNumber: '', quantity: 0, unitCost: '', totalCost: '', orderDate: new Date().toISOString().slice(0, 10), expectedDate: '', status: 'pending', notes: '' }); setOpen(true) }
  function openEdit(o: typeof orders[0]) {
    setEditing(o)
    setForm({ productId: o.productId, cmoId: o.cmoId, orderNumber: o.orderNumber ?? '', quantity: o.quantity, unitCost: o.unitCost ?? '', totalCost: o.totalCost ?? '', orderDate: o.orderDate ?? '', expectedDate: o.expectedDate ?? '', status: o.status ?? 'pending', notes: o.notes ?? '' })
    setOpen(true)
  }

  function calcTotal(qty: number, unit: string) {
    if (qty && unit) setForm(f => ({ ...f, totalCost: String(qty * Number(unit)) }))
  }

  async function handleSave() {
    setSaving(true)
    try {
      if (editing) await updateProductionOrder({ data: { id: editing.id, status: form.status, quantity: form.quantity, unitCost: form.unitCost, totalCost: form.totalCost, expectedDate: form.expectedDate, notes: form.notes } })
      else await createProductionOrder({ data: { ...form } })
      setOpen(false)
      navigate({ to: '/production' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteProductionOrder({ data: { id } })
    navigate({ to: '/production' })
  }

  return (
    <Layout>
      <PageHeader title="أوامر الإنتاج" subtitle={`${orders.length} أمر`} action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> أمر إنتاج جديد</span></Btn>} />
      <div className="p-6">
        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['رقم الأمر', 'المنتج', 'المصنع', 'الكمية', 'تكلفة الوحدة', 'إجمالي التكلفة', 'تاريخ الأمر', 'الموعد المتوقع', 'الحالة', 'إجراءات']} empty={orders.length === 0}>
            {orders.map(o => (
              <tr key={o.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 text-gray-600 text-sm">{o.orderNumber ?? `PO-${o.id}`}</td>
                <td className="py-3 px-4 font-medium text-gray-900">{o.productName}</td>
                <td className="py-3 px-4 text-gray-600">{o.cmoName}</td>
                <td className="py-3 px-4 text-gray-600">{o.quantity.toLocaleString()}</td>
                <td className="py-3 px-4 text-gray-600">{o.unitCost ? `${fmt(o.unitCost)} ج.م` : '-'}</td>
                <td className="py-3 px-4 font-medium text-red-700">{o.totalCost ? `${fmt(o.totalCost)} ج.م` : '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{o.orderDate ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{o.expectedDate ?? '-'}</td>
                <td className="py-3 px-4"><Badge status={o.status ?? 'pending'} /></td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(o)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(o.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل أمر الإنتاج' : 'أمر إنتاج جديد'}>
        <div className="space-y-4">
          {!editing && (
            <>
              <Select label="المنتج *" value={form.productId} onChange={e => setForm(f => ({ ...f, productId: Number(e.target.value) }))}>
                <option value={0}>اختر منتج...</option>
                {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
              </Select>
              <Select label="المصنع *" value={form.cmoId} onChange={e => setForm(f => ({ ...f, cmoId: Number(e.target.value) }))}>
                <option value={0}>اختر مصنع...</option>
                {cmos.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </Select>
              <Input label="رقم الأمر" value={form.orderNumber} onChange={e => setForm(f => ({ ...f, orderNumber: e.target.value }))} />
              <Input label="تاريخ الأمر" type="date" value={form.orderDate} onChange={e => setForm(f => ({ ...f, orderDate: e.target.value }))} />
            </>
          )}
          <Input label="الكمية *" type="number" value={form.quantity} onChange={e => { const q = Number(e.target.value); setForm(f => ({ ...f, quantity: q })); calcTotal(q, form.unitCost) }} />
          <Input label="تكلفة الوحدة (ج.م)" type="number" step="0.01" value={form.unitCost} onChange={e => { setForm(f => ({ ...f, unitCost: e.target.value })); calcTotal(form.quantity, e.target.value) }} />
          <Input label="إجمالي التكلفة (ج.م)" type="number" step="0.01" value={form.totalCost} onChange={e => setForm(f => ({ ...f, totalCost: e.target.value }))} />
          <Input label="الموعد المتوقع للاستلام" type="date" value={form.expectedDate} onChange={e => setForm(f => ({ ...f, expectedDate: e.target.value }))} />
          <Select label="الحالة" value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))}>
            {STATUSES.map(s => <option key={s.value} value={s.value}>{s.label}</option>)}
          </Select>
          <Textarea label="ملاحظات" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
