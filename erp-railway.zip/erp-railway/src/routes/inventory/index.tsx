import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, fmt } from '../../components/Layout'
import { getInventory, getGoodsReceipts, createGoodsReceipt } from '../../server/inventory.functions'
import { getProducts } from '../../server/products.functions'
import { getProductionOrders } from '../../server/production.functions'
import { Plus } from 'lucide-react'

export const Route = createFileRoute('/inventory/')({
  loader: async () => {
    const [inventory, receipts, products, orders] = await Promise.all([
      getInventory(), getGoodsReceipts(), getProducts(), getProductionOrders()
    ])
    return { inventory, receipts, products, orders }
  },
  component: InventoryPage,
})

function InventoryPage() {
  const { inventory, receipts, products, orders } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [tab, setTab] = useState<'stock' | 'receipts'>('stock')
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({ productId: 0, productionOrderId: 0, quantityReceived: 0, batchNumber: '', expiryDate: '', receiptDate: new Date().toISOString().slice(0, 10), unitCost: '', notes: '' })
  const [saving, setSaving] = useState(false)

  const totalValue = inventory.reduce((s, i) => s + Number(i.quantity) * Number(i.unitCost ?? 0), 0)

  async function handleSave() {
    setSaving(true)
    try {
      await createGoodsReceipt({ data: { ...form, productionOrderId: form.productionOrderId || undefined } })
      setOpen(false)
      navigate({ to: '/inventory' })
    } finally { setSaving(false) }
  }

  return (
    <Layout>
      <PageHeader title="المخزون واستلام البضاعة" subtitle={`إجمالي قيمة المخزون: ${fmt(totalValue)} ج.م`} action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus size={16} /> تسجيل استلام</span></Btn>} />
      <div className="p-6">
        <div className="flex gap-2 mb-4">
          <button onClick={() => setTab('stock')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'stock' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>المخزون الحالي</button>
          <button onClick={() => setTab('receipts')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'receipts' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>سجل الاستلام</button>
        </div>

        {tab === 'stock' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['المنتج', 'رقم التشغيلة', 'الكمية', 'تكلفة الوحدة', 'إجمالي القيمة', 'تاريخ الانتهاء']} empty={inventory.length === 0}>
              {inventory.map(i => (
                <tr key={i.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{i.productName}</td>
                  <td className="py-3 px-4 text-gray-600">{i.batchNumber ?? '-'}</td>
                  <td className={`py-3 px-4 font-bold ${i.quantity < 100 ? 'text-red-600' : 'text-gray-900'}`}>{i.quantity.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600">{i.unitCost ? `${fmt(i.unitCost)} ج.م` : '-'}</td>
                  <td className="py-3 px-4 font-medium text-blue-700">{fmt(Number(i.quantity) * Number(i.unitCost ?? 0))} ج.م</td>
                  <td className="py-3 px-4 text-gray-600 text-sm">{i.expiryDate ?? '-'}</td>
                </tr>
              ))}
            </Table>
          </div>
        )}

        {tab === 'receipts' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['المنتج', 'الكمية المستلمة', 'رقم التشغيلة', 'تاريخ الاستلام', 'تكلفة الوحدة', 'تاريخ الانتهاء', 'ملاحظات']} empty={receipts.length === 0}>
              {receipts.map(r => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 font-medium text-gray-900">{r.productName}</td>
                  <td className="py-3 px-4 font-bold text-emerald-700">{r.quantityReceived.toLocaleString()}</td>
                  <td className="py-3 px-4 text-gray-600">{r.batchNumber ?? '-'}</td>
                  <td className="py-3 px-4 text-gray-600 text-sm">{r.receiptDate ?? '-'}</td>
                  <td className="py-3 px-4 text-gray-600">{r.unitCost ? `${fmt(r.unitCost)} ج.م` : '-'}</td>
                  <td className="py-3 px-4 text-gray-600 text-sm">{r.expiryDate ?? '-'}</td>
                  <td className="py-3 px-4 text-gray-500 text-sm">{r.notes ?? '-'}</td>
                </tr>
              ))}
            </Table>
          </div>
        )}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="تسجيل استلام بضاعة">
        <div className="space-y-4">
          <Select label="المنتج *" value={form.productId} onChange={e => setForm(f => ({ ...f, productId: Number(e.target.value) }))}>
            <option value={0}>اختر منتج...</option>
            {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </Select>
          <Select label="أمر الإنتاج (اختياري)" value={form.productionOrderId} onChange={e => setForm(f => ({ ...f, productionOrderId: Number(e.target.value) }))}>
            <option value={0}>بدون أمر إنتاج</option>
            {orders.filter(o => o.productId === form.productId).map(o => <option key={o.id} value={o.id}>{o.orderNumber ?? `PO-${o.id}`} - {o.productName}</option>)}
          </Select>
          <Input label="الكمية المستلمة *" type="number" value={form.quantityReceived} onChange={e => setForm(f => ({ ...f, quantityReceived: Number(e.target.value) }))} />
          <Input label="رقم التشغيلة" value={form.batchNumber} onChange={e => setForm(f => ({ ...f, batchNumber: e.target.value }))} />
          <Input label="تاريخ الاستلام" type="date" value={form.receiptDate} onChange={e => setForm(f => ({ ...f, receiptDate: e.target.value }))} />
          <Input label="تاريخ انتهاء الصلاحية" type="date" value={form.expiryDate} onChange={e => setForm(f => ({ ...f, expiryDate: e.target.value }))} />
          <Input label="تكلفة الوحدة (ج.م)" type="number" step="0.01" value={form.unitCost} onChange={e => setForm(f => ({ ...f, unitCost: e.target.value }))} />
          <Textarea label="ملاحظات" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.productId || !form.quantityReceived}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
