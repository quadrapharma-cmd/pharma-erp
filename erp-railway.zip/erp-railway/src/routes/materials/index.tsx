import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, StatCard, fmt } from '../../components/Layout'
import {
  getMaterials, createMaterial, updateMaterial, deleteMaterial,
  getMaterialReceipts, createMaterialReceipt,
} from '../../server/materials.functions'
import { Plus, Pencil, Trash2, AlertTriangle, Package, FlaskConical } from 'lucide-react'

export const Route = createFileRoute('/materials/')({
  loader: async () => ({
    materials: await getMaterials(),
    receipts: await getMaterialReceipts(),
  }),
  component: MaterialsPage,
})

type Material = Awaited<ReturnType<typeof getMaterials>>[0]
type Receipt = Awaited<ReturnType<typeof getMaterialReceipts>>[0]

const UNITS = ['كجم', 'جم', 'مجم', 'لتر', 'مل', 'قطعة', 'علبة', 'كرتون', 'لفة', 'أمبولة']
const TABS = ['المواد الخام', 'مواد التغليف', 'الدُّفعات المستلمة']

function expiryStatus(dateStr: string | null | undefined): 'ok' | 'soon' | 'expired' {
  if (!dateStr) return 'ok'
  const exp = new Date(dateStr)
  const now = new Date()
  const daysLeft = (exp.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
  if (daysLeft < 0) return 'expired'
  if (daysLeft <= 90) return 'soon'
  return 'ok'
}

function ExpiryBadge({ date }: { date: string | null | undefined }) {
  if (!date) return <span className="text-gray-400">-</span>
  const status = expiryStatus(date)
  const cls = {
    ok: 'text-emerald-700',
    soon: 'bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full',
    expired: 'bg-red-100 text-red-700 px-2 py-0.5 rounded-full',
  }[status]
  return <span className={`text-xs font-medium ${cls}`}>{date}</span>
}

function MaterialsPage() {
  const { materials: allMaterials, receipts } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [tab, setTab] = useState(0)

  // material modal
  const [matOpen, setMatOpen] = useState(false)
  const [editingMat, setEditingMat] = useState<Material | null>(null)
  const [matForm, setMatForm] = useState({ name: '', materialType: 'raw_material', unit: 'كجم', unitCost: '', reorderLevel: '', supplier: '', notes: '', status: 'active' })
  const [matSaving, setMatSaving] = useState(false)

  // receipt modal
  const [rcptOpen, setRcptOpen] = useState(false)
  const [rcptForm, setRcptForm] = useState({ materialId: '', quantityReceived: '', batchNumber: '', expiryDate: '', receiptDate: '', unitCost: '', supplier: '', invoiceNumber: '', notes: '' })
  const [rcptSaving, setRcptSaving] = useState(false)

  const rawMaterials = allMaterials.filter(m => m.materialType === 'raw_material')
  const packagingMaterials = allMaterials.filter(m => m.materialType === 'packaging')

  // Expiry warnings from receipts
  const expiryWarnings = receipts.filter(r => expiryStatus(r.expiryDate) !== 'ok').length
  const lowStock = allMaterials.filter(m => m.reorderLevel && Number(m.currentStock) <= Number(m.reorderLevel)).length

  function openAddMat(type: string) {
    setEditingMat(null)
    setMatForm({ name: '', materialType: type, unit: 'كجم', unitCost: '', reorderLevel: '', supplier: '', notes: '', status: 'active' })
    setMatOpen(true)
  }

  function openEditMat(m: Material) {
    setEditingMat(m)
    setMatForm({
      name: m.name,
      materialType: m.materialType,
      unit: m.unit,
      unitCost: m.unitCost ?? '',
      reorderLevel: m.reorderLevel ?? '',
      supplier: m.supplier ?? '',
      notes: m.notes ?? '',
      status: m.status ?? 'active',
    })
    setMatOpen(true)
  }

  async function handleSaveMat() {
    setMatSaving(true)
    try {
      if (editingMat) await updateMaterial({ data: { id: editingMat.id, ...matForm } })
      else await createMaterial({ data: matForm })
      setMatOpen(false)
      navigate({ to: '/materials' })
    } finally { setMatSaving(false) }
  }

  async function handleDeleteMat(id: number) {
    if (!confirm('هل أنت متأكد من الحذف؟')) return
    await deleteMaterial({ data: { id } })
    navigate({ to: '/materials' })
  }

  async function handleSaveRcpt() {
    setRcptSaving(true)
    try {
      await createMaterialReceipt({ data: { ...rcptForm, materialId: Number(rcptForm.materialId) } })
      setRcptOpen(false)
      navigate({ to: '/materials' })
    } finally { setRcptSaving(false) }
  }

  const currentMaterials = tab === 0 ? rawMaterials : packagingMaterials

  return (
    <Layout>
      <PageHeader
        title="المواد الخام والتغليف"
        subtitle={`${rawMaterials.length} مادة خام · ${packagingMaterials.length} مادة تغليف`}
        action={
          <div className="flex gap-2">
            <Btn onClick={() => { setRcptForm({ materialId: '', quantityReceived: '', batchNumber: '', expiryDate: '', receiptDate: '', unitCost: '', supplier: '', invoiceNumber: '', notes: '' }); setRcptOpen(true) }}>
              <span className="flex items-center gap-2"><Plus size={16} /> استلام مواد</span>
            </Btn>
          </div>
        }
      />

      {/* KPIs */}
      <div className="p-6 pb-0 grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="إجمالي المواد الخام" value={rawMaterials.length} color="text-blue-600" />
        <StatCard title="مواد التغليف" value={packagingMaterials.length} color="text-purple-600" />
        <StatCard title="دُفعات قاربت الانتهاء / منتهية" value={expiryWarnings} color={expiryWarnings > 0 ? "text-red-600" : "text-emerald-600"} />
        <StatCard title="مواد تحت حد إعادة الطلب" value={lowStock} color={lowStock > 0 ? "text-amber-600" : "text-emerald-600"} />
      </div>

      {/* Tabs */}
      <div className="p-6">
        <div className="flex gap-1 mb-4 bg-gray-100 rounded-lg p-1 w-fit">
          {TABS.map((t, i) => (
            <button
              key={t}
              onClick={() => setTab(i)}
              className={`px-4 py-2 text-sm rounded-md font-medium transition-all ${tab === i ? 'bg-white shadow text-emerald-700' : 'text-gray-600 hover:text-gray-800'}`}
            >
              {t}
            </button>
          ))}
        </div>

        {tab < 2 ? (
          <div className="bg-white rounded-xl shadow-sm border">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="font-semibold text-gray-800 flex items-center gap-2">
                {tab === 0 ? <FlaskConical size={18} className="text-blue-600" /> : <Package size={18} className="text-purple-600" />}
                {TABS[tab]}
                <span className="text-sm font-normal text-gray-500">({currentMaterials.length})</span>
              </h2>
              <Btn onClick={() => openAddMat(tab === 0 ? 'raw_material' : 'packaging')}>
                <span className="flex items-center gap-2"><Plus size={15} /> إضافة</span>
              </Btn>
            </div>
            <Table
              headers={['اسم المادة', 'الوحدة', 'المخزون الحالي', 'حد إعادة الطلب', 'تكلفة الوحدة', 'المورد', 'الحالة', 'إجراءات']}
              empty={currentMaterials.length === 0}
            >
              {currentMaterials.map(m => {
                const isLow = m.reorderLevel && Number(m.currentStock) <= Number(m.reorderLevel)
                return (
                  <tr key={m.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-900">
                      <div className="flex items-center gap-2">
                        {isLow && <AlertTriangle size={14} className="text-amber-500 shrink-0" />}
                        {m.name}
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{m.unit}</td>
                    <td className={`py-3 px-4 font-medium ${isLow ? 'text-amber-600' : 'text-gray-800'}`}>
                      {fmt(m.currentStock)} {m.unit}
                    </td>
                    <td className="py-3 px-4 text-gray-500">{m.reorderLevel ? `${fmt(m.reorderLevel)} ${m.unit}` : '-'}</td>
                    <td className="py-3 px-4 font-medium text-gray-800">{m.unitCost ? `${fmt(m.unitCost)} ج.م` : '-'}</td>
                    <td className="py-3 px-4 text-gray-500 text-sm">{m.supplier ?? '-'}</td>
                    <td className="py-3 px-4"><Badge status={m.status ?? 'active'} /></td>
                    <td className="py-3 px-4">
                      <div className="flex gap-2">
                        <button onClick={() => openEditMat(m)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                        <button onClick={() => handleDeleteMat(m.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </Table>
          </div>
        ) : (
          /* Receipts Tab */
          <div className="bg-white rounded-xl shadow-sm border">
            <div className="p-4 border-b flex items-center justify-between">
              <h2 className="font-semibold text-gray-800">الدُّفعات المستلمة ({receipts.length})</h2>
              <Btn onClick={() => { setRcptForm({ materialId: '', quantityReceived: '', batchNumber: '', expiryDate: '', receiptDate: '', unitCost: '', supplier: '', invoiceNumber: '', notes: '' }); setRcptOpen(true) }}>
                <span className="flex items-center gap-2"><Plus size={15} /> تسجيل استلام</span>
              </Btn>
            </div>
            <Table
              headers={['المادة', 'النوع', 'الكمية المستلمة', 'رقم الدُّفعة', 'تاريخ الصلاحية', 'تاريخ الاستلام', 'تكلفة الوحدة', 'رقم الفاتورة', 'المورد']}
              empty={receipts.length === 0}
            >
              {receipts.map(r => {
                const status = expiryStatus(r.expiryDate)
                return (
                  <tr key={r.id} className={`hover:bg-gray-50 ${status === 'expired' ? 'bg-red-50' : status === 'soon' ? 'bg-amber-50' : ''}`}>
                    <td className="py-3 px-4 font-medium text-gray-900">{r.materialName ?? '-'}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${r.materialType === 'raw_material' ? 'bg-blue-100 text-blue-700' : 'bg-purple-100 text-purple-700'}`}>
                        {r.materialType === 'raw_material' ? 'خام' : 'تغليف'}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium">{fmt(r.quantityReceived)} {r.materialUnit}</td>
                    <td className="py-3 px-4 text-gray-600 text-sm">{r.batchNumber ?? '-'}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        {status !== 'ok' && <AlertTriangle size={13} className={status === 'expired' ? 'text-red-500' : 'text-amber-500'} />}
                        <ExpiryBadge date={r.expiryDate} />
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{r.receiptDate ?? '-'}</td>
                    <td className="py-3 px-4 font-medium">{r.unitCost ? `${fmt(r.unitCost)} ج.م` : '-'}</td>
                    <td className="py-3 px-4 text-gray-500 text-sm">{r.invoiceNumber ?? '-'}</td>
                    <td className="py-3 px-4 text-gray-500 text-sm">{r.supplier ?? '-'}</td>
                  </tr>
                )
              })}
            </Table>
          </div>
        )}
      </div>

      {/* Material Add/Edit Modal */}
      <Modal open={matOpen} onClose={() => setMatOpen(false)} title={editingMat ? 'تعديل مادة' : `إضافة ${tab === 0 ? 'مادة خام' : 'مادة تغليف'}`}>
        <div className="space-y-4">
          <Input label="اسم المادة *" value={matForm.name} onChange={e => setMatForm(f => ({ ...f, name: e.target.value }))} required />
          <Select label="نوع المادة *" value={matForm.materialType} onChange={e => setMatForm(f => ({ ...f, materialType: e.target.value }))}>
            <option value="raw_material">مادة خام</option>
            <option value="packaging">مادة تغليف</option>
          </Select>
          <Select label="وحدة القياس *" value={matForm.unit} onChange={e => setMatForm(f => ({ ...f, unit: e.target.value }))}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </Select>
          <Input label="تكلفة الوحدة (ج.م)" type="number" step="0.0001" value={matForm.unitCost} onChange={e => setMatForm(f => ({ ...f, unitCost: e.target.value }))} placeholder="0.00" />
          <Input label="حد إعادة الطلب" type="number" step="0.001" value={matForm.reorderLevel} onChange={e => setMatForm(f => ({ ...f, reorderLevel: e.target.value }))} placeholder="الحد الأدنى قبل إعادة الطلب" />
          <Input label="المورد" value={matForm.supplier} onChange={e => setMatForm(f => ({ ...f, supplier: e.target.value }))} />
          <Select label="الحالة" value={matForm.status} onChange={e => setMatForm(f => ({ ...f, status: e.target.value }))}>
            <option value="active">نشط</option>
            <option value="inactive">غير نشط</option>
          </Select>
          <Textarea label="ملاحظات" value={matForm.notes} onChange={e => setMatForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSaveMat} disabled={matSaving || !matForm.name}>{matSaving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setMatOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>

      {/* Receipt Modal */}
      <Modal open={rcptOpen} onClose={() => setRcptOpen(false)} title="تسجيل استلام مواد">
        <div className="space-y-4">
          <Select label="المادة *" value={rcptForm.materialId} onChange={e => setRcptForm(f => ({ ...f, materialId: e.target.value }))}>
            <option value="">اختر مادة...</option>
            <optgroup label="مواد خام">
              {rawMaterials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
            </optgroup>
            <optgroup label="مواد التغليف">
              {packagingMaterials.map(m => <option key={m.id} value={m.id}>{m.name} ({m.unit})</option>)}
            </optgroup>
          </Select>
          <Input label="الكمية المستلمة *" type="number" step="0.001" value={rcptForm.quantityReceived} onChange={e => setRcptForm(f => ({ ...f, quantityReceived: e.target.value }))} />
          <Input label="رقم الدُّفعة (Batch No.)" value={rcptForm.batchNumber} onChange={e => setRcptForm(f => ({ ...f, batchNumber: e.target.value }))} placeholder="مثال: BT-2026-001" />
          <Input label="تاريخ انتهاء الصلاحية" type="date" value={rcptForm.expiryDate} onChange={e => setRcptForm(f => ({ ...f, expiryDate: e.target.value }))} />
          <Input label="تاريخ الاستلام" type="date" value={rcptForm.receiptDate} onChange={e => setRcptForm(f => ({ ...f, receiptDate: e.target.value }))} />
          <Input label="تكلفة الوحدة (ج.م)" type="number" step="0.0001" value={rcptForm.unitCost} onChange={e => setRcptForm(f => ({ ...f, unitCost: e.target.value }))} placeholder="0.00" />
          <Input label="المورد" value={rcptForm.supplier} onChange={e => setRcptForm(f => ({ ...f, supplier: e.target.value }))} />
          <Input label="رقم الفاتورة" value={rcptForm.invoiceNumber} onChange={e => setRcptForm(f => ({ ...f, invoiceNumber: e.target.value }))} />
          <Textarea label="ملاحظات" value={rcptForm.notes} onChange={e => setRcptForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSaveRcpt} disabled={rcptSaving || !rcptForm.materialId || !rcptForm.quantityReceived}>
              {rcptSaving ? 'جاري الحفظ...' : 'تسجيل الاستلام'}
            </Btn>
            <Btn variant="secondary" onClick={() => setRcptOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
