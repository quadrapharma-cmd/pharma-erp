import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Textarea, Btn, Table, Badge, StatCard, fmt } from '../../components/Layout'
import { getExpenses, createExpense, updateExpense, deleteExpense } from '../../server/expenses.functions'
import { getProducts } from '../../server/products.functions'
import { Plus, Pencil, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/expenses/')({
  loader: async () => {
    const [expenses, products] = await Promise.all([getExpenses(), getProducts()])
    return { expenses, products }
  },
  component: ExpensesPage,
})

const CATEGORIES = {
  direct: ['تكاليف تصنيع', 'مواد خام', 'تعبئة وتغليف', 'نقل المنتج', 'تخزين', 'جودة ورقابة'],
  indirect: ['رواتب وأجور', 'دعاية وإعلان', 'تسجيل دوائي', 'إيجار', 'خدمات', 'مصاريف إدارية', 'صيانة', 'تأمين', 'قانونية ومحاسبة'],
}
const DEPARTMENTS = ['التصنيع', 'التسجيل الدوائي', 'الحسابات', 'الدعاية والمبيعات', 'الإدارة']

function ExpensesPage() {
  const { expenses, products } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<typeof expenses[0] | null>(null)
  const [form, setForm] = useState({ description: '', amount: '', expenseType: 'direct', category: '', department: '', expenseDate: new Date().toISOString().slice(0, 10), reference: '', productId: 0, notes: '' })
  const [saving, setSaving] = useState(false)
  const [filter, setFilter] = useState<'all' | 'direct' | 'indirect'>('all')

  const direct = expenses.filter(e => e.expenseType === 'direct')
  const indirect = expenses.filter(e => e.expenseType === 'indirect')
  const totalDirect = direct.reduce((s, e) => s + Number(e.amount), 0)
  const totalIndirect = indirect.reduce((s, e) => s + Number(e.amount), 0)
  const filtered = filter === 'all' ? expenses : expenses.filter(e => e.expenseType === filter)

  function openAdd() { setEditing(null); setForm({ description: '', amount: '', expenseType: 'direct', category: '', department: '', expenseDate: new Date().toISOString().slice(0, 10), reference: '', productId: 0, notes: '' }); setOpen(true) }
  function openEdit(e: typeof expenses[0]) {
    setEditing(e)
    setForm({ description: e.description, amount: e.amount, expenseType: e.expenseType, category: e.category, department: e.department ?? '', expenseDate: e.expenseDate ?? '', reference: e.reference ?? '', productId: e.productId ?? 0, notes: e.notes ?? '' })
    setOpen(true)
  }

  async function handleSave() {
    setSaving(true)
    try {
      const data = { ...form, productId: form.productId || undefined }
      if (editing) await updateExpense({ data: { id: editing.id, ...data } })
      else await createExpense({ data })
      setOpen(false)
      navigate({ to: '/expenses' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteExpense({ data: { id } })
    navigate({ to: '/expenses' })
  }

  return (
    <Layout>
      <PageHeader title="إدارة المصروفات" subtitle="التكاليف المباشرة وغير المباشرة" action={<Btn onClick={openAdd}><span className="flex items-center gap-2"><Plus size={16} /> إضافة مصروف</span></Btn>} />
      <div className="p-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <StatCard title="إجمالي التكاليف المباشرة" value={`${fmt(totalDirect)} ج.م`} color="text-blue-600" sub={`${direct.length} بند`} />
          <StatCard title="إجمالي التكاليف غير المباشرة" value={`${fmt(totalIndirect)} ج.م`} color="text-purple-600" sub={`${indirect.length} بند`} />
          <StatCard title="إجمالي المصروفات" value={`${fmt(totalDirect + totalIndirect)} ج.م`} color="text-red-600" sub={`${expenses.length} بند إجمالي`} />
        </div>

        <div className="flex gap-2 mb-4">
          {(['all', 'direct', 'indirect'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-4 py-2 rounded-lg text-sm font-medium ${filter === f ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>
              {f === 'all' ? 'الكل' : f === 'direct' ? 'مباشرة' : 'غير مباشرة'}
            </button>
          ))}
        </div>

        <div className="bg-white rounded-xl shadow-sm border">
          <Table headers={['الوصف', 'المبلغ', 'النوع', 'الفئة', 'القسم', 'التاريخ', 'المنتج', 'المرجع', 'إجراءات']} empty={filtered.length === 0}>
            {filtered.map(e => (
              <tr key={e.id} className="hover:bg-gray-50">
                <td className="py-3 px-4 font-medium text-gray-900">{e.description}</td>
                <td className={`py-3 px-4 font-bold ${e.expenseType === 'direct' ? 'text-blue-700' : 'text-purple-700'}`}>{fmt(e.amount)} ج.م</td>
                <td className="py-3 px-4"><Badge status={e.expenseType} /></td>
                <td className="py-3 px-4 text-gray-600 text-sm">{e.category}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{e.department ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{e.expenseDate ?? '-'}</td>
                <td className="py-3 px-4 text-gray-600 text-sm">{e.productName ?? '-'}</td>
                <td className="py-3 px-4 text-gray-500 text-xs">{e.reference ?? '-'}</td>
                <td className="py-3 px-4">
                  <div className="flex gap-2">
                    <button onClick={() => openEdit(e)} className="text-blue-600 hover:text-blue-800"><Pencil size={15} /></button>
                    <button onClick={() => handleDelete(e.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </Table>
        </div>
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title={editing ? 'تعديل مصروف' : 'إضافة مصروف جديد'}>
        <div className="space-y-4">
          <Input label="الوصف *" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} required />
          <Input label="المبلغ (ج.م) *" type="number" step="0.01" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} required />
          <Select label="نوع التكلفة *" value={form.expenseType} onChange={e => setForm(f => ({ ...f, expenseType: e.target.value, category: '' }))}>
            <option value="direct">تكلفة مباشرة</option>
            <option value="indirect">تكلفة غير مباشرة</option>
          </Select>
          <Select label="الفئة *" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
            <option value="">اختر فئة...</option>
            {(CATEGORIES[form.expenseType as keyof typeof CATEGORIES] ?? []).map(c => <option key={c} value={c}>{c}</option>)}
          </Select>
          <Select label="القسم" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))}>
            <option value="">اختر قسم...</option>
            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
          </Select>
          <Input label="التاريخ" type="date" value={form.expenseDate} onChange={e => setForm(f => ({ ...f, expenseDate: e.target.value }))} />
          <Input label="المرجع" value={form.reference} onChange={e => setForm(f => ({ ...f, reference: e.target.value }))} />
          {form.expenseType === 'direct' && (
            <Select label="المنتج (للتكاليف المباشرة)" value={form.productId} onChange={e => setForm(f => ({ ...f, productId: Number(e.target.value) }))}>
              <option value={0}>بدون منتج محدد</option>
              {products.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </Select>
          )}
          <Textarea label="ملاحظات" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.description || !form.amount || !form.category}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
