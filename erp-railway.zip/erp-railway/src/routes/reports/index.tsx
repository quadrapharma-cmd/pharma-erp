import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { Bar, Doughnut } from 'react-chartjs-2'
import { Chart as ChartJS, CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend } from 'chart.js'
import { Layout, PageHeader, StatCard, Table, fmt } from '../../components/Layout'
import { getFinancialSummary, getExpensesByCategory, getBudgetVsActual, getInventoryValue } from '../../server/reports.functions'

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Title, Tooltip, Legend)

export const Route = createFileRoute('/reports/')({
  loader: async () => {
    const [summary, categories, budgetComp, inventoryValue] = await Promise.all([
      getFinancialSummary(), getExpensesByCategory(), getBudgetVsActual(), getInventoryValue()
    ])
    return { summary, categories, budgetComp, inventoryValue }
  },
  component: ReportsPage,
})

function ReportsPage() {
  const { summary, categories, budgetComp, inventoryValue } = Route.useLoaderData()
  const [mounted, setMounted] = useState(false)
  const [tab, setTab] = useState<'pl' | 'balance' | 'budget' | 'inventory'>('pl')
  useEffect(() => setMounted(true), [])

  const totalInventoryValue = inventoryValue.reduce((s, i) => s + Number(i.totalValue ?? 0), 0)

  const directExpenses = categories.filter(c => c.expenseType === 'direct')
  const indirectExpenses = categories.filter(c => c.expenseType === 'indirect')

  const costChartData = {
    labels: ['تكاليف مباشرة', 'تكاليف غير مباشرة', 'تكاليف إنتاج'],
    datasets: [{
      data: [summary.totalDirectCosts, summary.totalIndirectCosts, summary.totalProductionCosts],
      backgroundColor: ['rgba(59,130,246,0.85)', 'rgba(139,92,246,0.85)', 'rgba(245,158,11,0.85)'],
      borderWidth: 0,
    }],
  }

  const budgetChartData = {
    labels: budgetComp.slice(0, 8).map(b => b.category),
    datasets: [
      { label: 'المخطط', data: budgetComp.slice(0, 8).map(b => Number(b.budgetedAmount)), backgroundColor: 'rgba(59,130,246,0.7)' },
      { label: 'الفعلي', data: budgetComp.slice(0, 8).map(b => b.actualAmount), backgroundColor: 'rgba(239,68,68,0.7)' },
    ],
  }

  return (
    <Layout>
      <PageHeader title="التقارير المالية" subtitle="قائمة الدخل • الميزانية العمومية • التحليل المالي" />
      <div className="p-6">
        <div className="flex gap-2 mb-6 flex-wrap">
          {[
            { key: 'pl', label: 'قائمة الدخل (ربح/خسارة)' },
            { key: 'balance', label: 'المركز المالي' },
            { key: 'budget', label: 'الميزانية مقابل الفعلي' },
            { key: 'inventory', label: 'قيمة المخزون' },
          ].map(t => (
            <button key={t.key} onClick={() => setTab(t.key as any)} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === t.key ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600 hover:border-emerald-400'}`}>
              {t.label}
            </button>
          ))}
        </div>

        {/* قائمة الدخل */}
        {tab === 'pl' && (
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-lg font-bold text-gray-900 mb-6 pb-3 border-b">قائمة الدخل</h2>
              <div className="space-y-1">
                <div className="flex justify-between py-2 border-b border-dashed">
                  <span className="font-semibold text-gray-700">الإيرادات</span>
                  <span className="font-bold text-emerald-700 text-lg">{fmt(summary.totalRevenue)} ج.م</span>
                </div>
                <div className="pr-4 pt-2 space-y-1">
                  <p className="text-sm font-medium text-gray-500 mb-2">التكاليف:</p>
                  <div className="flex justify-between py-1.5 hover:bg-gray-50 px-2 rounded">
                    <span className="text-gray-700">تكاليف الإنتاج (التصنيع لدى الغير)</span>
                    <span className="text-red-600 font-medium">{fmt(summary.totalProductionCosts)} ج.م</span>
                  </div>
                  <div className="flex justify-between py-1.5 hover:bg-gray-50 px-2 rounded">
                    <span className="text-gray-700">تكاليف مباشرة أخرى</span>
                    <span className="text-red-600 font-medium">{fmt(summary.totalDirectCosts)} ج.م</span>
                  </div>
                  {directExpenses.map(e => (
                    <div key={e.category} className="flex justify-between py-1 pr-6 text-sm hover:bg-gray-50 px-2 rounded">
                      <span className="text-gray-500">• {e.category}</span>
                      <span className="text-gray-600">{fmt(e.total)} ج.م</span>
                    </div>
                  ))}
                </div>
                <div className="flex justify-between py-2 mt-2 border-t border-dashed font-semibold">
                  <span className="text-gray-700">مجمل الربح</span>
                  <span className={`font-bold text-lg ${(summary.totalRevenue - summary.totalProductionCosts - summary.totalDirectCosts) >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
                    {fmt(summary.totalRevenue - summary.totalProductionCosts - summary.totalDirectCosts)} ج.م
                  </span>
                </div>
                <div className="pr-4 pt-2 space-y-1">
                  <p className="text-sm font-medium text-gray-500 mb-2">المصروفات غير المباشرة:</p>
                  {indirectExpenses.map(e => (
                    <div key={e.category} className="flex justify-between py-1.5 hover:bg-gray-50 px-2 rounded">
                      <span className="text-gray-700">• {e.category}</span>
                      <span className="text-red-600 font-medium">{fmt(e.total)} ج.م</span>
                    </div>
                  ))}
                  <div className="flex justify-between py-1.5 hover:bg-gray-50 px-2 rounded border-t border-dashed mt-2">
                    <span className="text-gray-700 font-medium">إجمالي المصروفات غير المباشرة</span>
                    <span className="text-red-700 font-bold">{fmt(summary.totalIndirectCosts)} ج.م</span>
                  </div>
                </div>
                <div className={`flex justify-between py-3 mt-3 border-t-2 ${summary.netProfit >= 0 ? 'border-emerald-500' : 'border-red-500'}`}>
                  <span className="font-bold text-gray-900 text-lg">{summary.netProfit >= 0 ? 'صافي الربح' : 'صافي الخسارة'}</span>
                  <span className={`font-bold text-xl ${summary.netProfit >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>
                    {fmt(summary.netProfit)} ج.م
                  </span>
                </div>
                <p className="text-sm text-gray-500 text-left">هامش الربح الصافي: {summary.profitMargin}%</p>
              </div>
            </div>

            {mounted && (
              <div className="bg-white rounded-xl shadow-sm border p-6">
                <h3 className="font-bold text-gray-900 mb-4">توزيع التكاليف</h3>
                <div className="max-w-sm mx-auto">
                  <Doughnut data={costChartData} options={{ responsive: true, plugins: { legend: { position: 'bottom' } } }} />
                </div>
              </div>
            )}
          </div>
        )}

        {/* المركز المالي */}
        {tab === 'balance' && (
          <div className="bg-white rounded-xl shadow-sm border p-6">
            <h2 className="text-lg font-bold text-gray-900 mb-6 pb-3 border-b">المركز المالي (الميزانية العمومية)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-bold text-blue-700 mb-3 pb-2 border-b border-blue-200">الأصول</h3>
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b border-dashed">
                    <span className="text-gray-700">قيمة المخزون</span>
                    <span className="font-medium text-blue-700">{fmt(totalInventoryValue)} ج.م</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-dashed">
                    <span className="text-gray-700">الذمم المدينة (الموزعون)</span>
                    <span className="font-medium text-blue-700">{fmt(summary.totalRevenue)} ج.م</span>
                  </div>
                  <div className="flex justify-between py-3 border-t-2 border-blue-500 font-bold">
                    <span className="text-gray-900">إجمالي الأصول</span>
                    <span className="text-blue-700 text-lg">{fmt(totalInventoryValue + summary.totalRevenue)} ج.م</span>
                  </div>
                </div>
              </div>
              <div>
                <h3 className="font-bold text-red-700 mb-3 pb-2 border-b border-red-200">الالتزامات وحقوق الملكية</h3>
                <div className="space-y-2">
                  <div className="flex justify-between py-2 border-b border-dashed">
                    <span className="text-gray-700">إجمالي المصروفات (التزامات)</span>
                    <span className="font-medium text-red-700">{fmt(summary.totalCosts)} ج.م</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-dashed">
                    <span className="text-gray-700">صافي حقوق الملكية</span>
                    <span className={`font-medium ${summary.netProfit >= 0 ? 'text-emerald-700' : 'text-red-700'}`}>{fmt(summary.netProfit)} ج.م</span>
                  </div>
                  <div className="flex justify-between py-3 border-t-2 border-red-500 font-bold">
                    <span className="text-gray-900">إجمالي الالتزامات + حقوق الملكية</span>
                    <span className="text-red-700 text-lg">{fmt(summary.totalCosts + summary.netProfit)} ج.م</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* الميزانية مقابل الفعلي */}
        {tab === 'budget' && (
          <div className="space-y-6">
            {mounted && budgetComp.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border p-6">
                <h3 className="font-bold text-gray-900 mb-4">المخطط مقابل الفعلي</h3>
                <Bar data={budgetChartData} options={{ responsive: true, plugins: { legend: { position: 'top' } }, scales: { y: { beginAtZero: true } } }} />
              </div>
            )}
            <div className="bg-white rounded-xl shadow-sm border">
              <Table headers={['الفئة', 'القسم', 'المخطط', 'الفعلي', 'الفرق', 'النسبة']} empty={budgetComp.length === 0}>
                {budgetComp.map(b => {
                  const pct = Number(b.budgetedAmount) > 0 ? (b.actualAmount / Number(b.budgetedAmount) * 100) : 0
                  return (
                    <tr key={b.id} className="hover:bg-gray-50">
                      <td className="py-3 px-4 font-medium text-gray-900">{b.category}</td>
                      <td className="py-3 px-4 text-gray-600">{b.department ?? 'عام'}</td>
                      <td className="py-3 px-4 text-blue-700 font-medium">{fmt(b.budgetedAmount)} ج.م</td>
                      <td className="py-3 px-4 text-red-700 font-medium">{fmt(b.actualAmount)} ج.م</td>
                      <td className={`py-3 px-4 font-bold ${b.variance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{fmt(b.variance)} ج.م</td>
                      <td className="py-3 px-4">
                        <span className={`text-sm font-medium ${pct > 100 ? 'text-red-600' : pct > 80 ? 'text-amber-600' : 'text-emerald-600'}`}>{pct.toFixed(1)}%</span>
                      </td>
                    </tr>
                  )
                })}
              </Table>
            </div>
          </div>
        )}

        {/* قيمة المخزون */}
        {tab === 'inventory' && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <StatCard title="إجمالي قيمة المخزون" value={`${fmt(totalInventoryValue)} ج.م`} color="text-blue-600" />
              <StatCard title="عدد الأصناف" value={inventoryValue.length} />
            </div>
            <div className="bg-white rounded-xl shadow-sm border">
              <Table headers={['المنتج', 'الكمية', 'تكلفة الوحدة', 'القيمة الإجمالية', 'تاريخ الانتهاء']} empty={inventoryValue.length === 0}>
                {inventoryValue.map(i => (
                  <tr key={i.productId} className="hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-900">{i.productName}</td>
                    <td className="py-3 px-4 text-gray-700">{i.quantity.toLocaleString()}</td>
                    <td className="py-3 px-4 text-gray-600">{i.unitCost ? `${fmt(i.unitCost)} ج.م` : '-'}</td>
                    <td className="py-3 px-4 font-bold text-blue-700">{fmt(i.totalValue)} ج.م</td>
                    <td className="py-3 px-4 text-gray-600 text-sm">{i.expiryDate ?? '-'}</td>
                  </tr>
                ))}
              </Table>
            </div>
          </div>
        )}
      </div>
    </Layout>
  )
}
