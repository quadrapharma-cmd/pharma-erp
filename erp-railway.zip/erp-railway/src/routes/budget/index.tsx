import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Layout, PageHeader, Modal, Input, Select, Btn, Table, StatCard, fmt } from '../../components/Layout'
import { getBudgetLines, createBudgetLine, updateBudgetLine, deleteBudgetLine } from '../../server/budget.functions'
import { getBudgetVsActual } from '../../server/reports.functions'
import { Plus, Trash2 } from 'lucide-react'

export const Route = createFileRoute('/budget/')({
  loader: async () => {
    const [lines, comparison] = await Promise.all([getBudgetLines(), getBudgetVsActual()])
    return { lines, comparison }
  },
  component: BudgetPage,
})

const CATEGORIES = ['تكاليف تصنيع', 'مواد خام', 'تعبئة وتغليف', 'نقل المنتج', 'تخزين', 'جودة ورقابة', 'رواتب وأجور', 'دعاية وإعلان', 'تسجيل دوائي', 'إيجار', 'خدمات', 'مصاريف إدارية', 'صيانة', 'تأمين', 'قانونية ومحاسبة']
const DEPARTMENTS = ['التصنيع', 'التسجيل الدوائي', 'الحسابات', 'الدعاية والمبيعات', 'الإدارة', 'كل الأقسام']
const MONTHS = ['يناير', 'فبراير', 'مارس', 'إبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر']

function BudgetPage() {
  const { lines, comparison } = Route.useLoaderData()
  const navigate = Route.useNavigate()
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<'budget' | 'compare'>('budget')
  const [form, setForm] = useState({ year: new Date().getFullYear(), month: 0, department: '', category: '', description: '', budgetedAmount: '' })
  const [saving, setSaving] = useState(false)

  const totalBudget = lines.reduce((s, l) => s + Number(l.budgetedAmount), 0)
  const totalActual = comparison.reduce((s, c) => s + c.actualAmount, 0)

  async function handleSave() {
    setSaving(true)
    try {
      await createBudgetLine({ data: { ...form, month: form.month || undefined } })
      setOpen(false)
      navigate({ to: '/budget' })
    } finally { setSaving(false) }
  }

  async function handleDelete(id: number) {
    if (!confirm('هل أنت متأكد؟')) return
    await deleteBudgetLine({ data: { id } })
    navigate({ to: '/budget' })
  }

  return (
    <Layout>
      <PageHeader title="إدارة الميزانية" subtitle="المخطط مقابل الفعلي" action={<Btn onClick={() => setOpen(true)}><span className="flex items-center gap-2"><Plus size={16} /> إضافة بند ميزانية</span></Btn>} />
      <div className="p-6">
        <div className="grid grid-cols-3 gap-4 mb-6">
          <StatCard title="إجمالي الميزانية" value={`${fmt(totalBudget)} ج.م`} color="text-blue-600" />
          <StatCard title="الإنفاق الفعلي" value={`${fmt(totalActual)} ج.م`} color="text-red-600" />
          <StatCard title="الفرق" value={`${fmt(totalBudget - totalActual)} ج.م`} color={totalBudget >= totalActual ? "text-emerald-600" : "text-red-600"} sub={totalBudget >= totalActual ? "في الحدود" : "تجاوز الميزانية"} />
        </div>

        <div className="flex gap-2 mb-4">
          <button onClick={() => setTab('budget')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'budget' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>بنود الميزانية</button>
          <button onClick={() => setTab('compare')} className={`px-4 py-2 rounded-lg text-sm font-medium ${tab === 'compare' ? 'bg-emerald-600 text-white' : 'bg-white border text-gray-600'}`}>المقارنة (مخطط vs فعلي)</button>
        </div>

        {tab === 'budget' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['السنة', 'الشهر', 'القسم', 'الفئة', 'الوصف', 'المبلغ المخطط', 'إجراءات']} empty={lines.length === 0}>
              {lines.map(l => (
                <tr key={l.id} className="hover:bg-gray-50">
                  <td className="py-3 px-4 text-gray-700">{l.year}</td>
                  <td className="py-3 px-4 text-gray-600">{l.month ? MONTHS[l.month - 1] : 'سنوي'}</td>
                  <td className="py-3 px-4 text-gray-600">{l.department ?? '-'}</td>
                  <td className="py-3 px-4 text-gray-600">{l.category}</td>
                  <td className="py-3 px-4 text-gray-500 text-sm">{l.description ?? '-'}</td>
                  <td className="py-3 px-4 font-bold text-blue-700">{fmt(l.budgetedAmount)} ج.م</td>
                  <td className="py-3 px-4"><button onClick={() => handleDelete(l.id)} className="text-red-600 hover:text-red-800"><Trash2 size={15} /></button></td>
                </tr>
              ))}
            </Table>
          </div>
        )}

        {tab === 'compare' && (
          <div className="bg-white rounded-xl shadow-sm border">
            <Table headers={['الفئة', 'المخطط', 'الفعلي', 'الفرق', 'نسبة الاستهلاك']} empty={comparison.length === 0}>
              {comparison.map(c => {
                const pct = Number(c.budgetedAmount) > 0 ? (c.actualAmount / Number(c.budgetedAmount) * 100) : 0
                return (
                  <tr key={c.id} className="hover:bg-gray-50">
                    <td className="py-3 px-4 font-medium text-gray-900">{c.category}</td>
                    <td className="py-3 px-4 text-blue-700 font-medium">{fmt(c.budgetedAmount)} ج.م</td>
                    <td className="py-3 px-4 text-red-700 font-medium">{fmt(c.actualAmount)} ج.م</td>
                    <td className={`py-3 px-4 font-bold ${c.variance >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>{fmt(c.variance)} ج.م</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div className={`h-2 rounded-full ${pct > 100 ? 'bg-red-500' : pct > 80 ? 'bg-amber-500' : 'bg-emerald-500'}`} style={{ width: `${Math.min(pct, 100)}%` }} />
                        </div>
                        <span className={`text-xs font-medium ${pct > 100 ? 'text-red-600' : 'text-gray-600'}`}>{pct.toFixed(0)}%</span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </Table>
          </div>
        )}
      </div>

      <Modal open={open} onClose={() => setOpen(false)} title="إضافة بند ميزانية">
        <div className="space-y-4">
          <Input label="السنة *" type="number" value={form.year} onChange={e => setForm(f => ({ ...f, year: Number(e.target.value) }))} />
          <Select label="الشهر (اتركه فارغاً للميزانية السنوية)" value={form.month} onChange={e => setForm(f => ({ ...f, month: Number(e.target.value) }))}>
            <option value={0}>سنوي</option>
            {MONTHS.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
          </Select>
          <Select label="القسم" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))}>
            <option value="">اختر قسم...</option>
            {DEPARTMENTS.map(d => <option key={d} value={d}>{d}</option>)}
          </Select>
          <Select label="الفئة *" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
            <option value="">اختر فئة...</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </Select>
          <Input label="الوصف" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
          <Input label="المبلغ المخطط (ج.م) *" type="number" step="0.01" value={form.budgetedAmount} onChange={e => setForm(f => ({ ...f, budgetedAmount: e.target.value }))} required />
          <div className="flex gap-3 pt-2">
            <Btn onClick={handleSave} disabled={saving || !form.category || !form.budgetedAmount}>{saving ? 'جاري الحفظ...' : 'حفظ'}</Btn>
            <Btn variant="secondary" onClick={() => setOpen(false)}>إلغاء</Btn>
          </div>
        </div>
      </Modal>
    </Layout>
  )
}
