import { createFileRoute } from '@tanstack/react-router'
import { useState, useEffect } from 'react'
import { Bar, Line, Doughnut } from 'react-chartjs-2'
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement,
  LineElement, PointElement, ArcElement, Title, Tooltip, Legend, Filler,
} from 'chart.js'
import { Layout, PageHeader, StatCard, fmt } from '../components/Layout'
import { getFinancialSummary, getExpensesByCategory, getMonthlySales } from '../server/reports.functions'
import { getProducts } from '../server/products.functions'
import { getInventory } from '../server/inventory.functions'

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, ArcElement, Title, Tooltip, Legend, Filler)

export const Route = createFileRoute('/')({
  loader: async () => {
    const [summary, categories, sales, products, inventory] = await Promise.all([
      getFinancialSummary(),
      getExpensesByCategory(),
      getMonthlySales(),
      getProducts(),
      getInventory(),
    ])
    return { summary, categories, sales, products, inventory }
  },
  component: Dashboard,
})

function Dashboard() {
  const { summary, categories, sales, products, inventory } = Route.useLoaderData()
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  const totalInventoryValue = inventory.reduce((sum, i) => sum + Number(i.quantity) * Number(i.unitCost ?? 0), 0)

  const salesChartData = {
    labels: sales.map(s => s.month),
    datasets: [{
      label: 'المبيعات (ج.م)',
      data: sales.map(s => Number(s.total ?? 0)),
      backgroundColor: 'rgba(16, 185, 129, 0.7)',
      borderRadius: 6,
    }],
  }

  const expenseTypeData = {
    labels: ['تكاليف مباشرة', 'تكاليف غير مباشرة', 'تكاليف إنتاج'],
    datasets: [{
      data: [summary.totalDirectCosts, summary.totalIndirectCosts, summary.totalProductionCosts],
      backgroundColor: ['rgba(59,130,246,0.8)', 'rgba(139,92,246,0.8)', 'rgba(245,158,11,0.8)'],
      borderWidth: 0,
    }],
  }

  const catMap = new Map<string, number>()
  categories.forEach(c => { catMap.set(c.category, (catMap.get(c.category) ?? 0) + Number(c.total ?? 0)) })
  const catChartData = {
    labels: [...catMap.keys()],
    datasets: [{
      label: 'المصروفات',
      data: [...catMap.values()],
      backgroundColor: 'rgba(239,68,68,0.7)',
      borderRadius: 4,
    }],
  }

  return (
    <Layout>
      <PageHeader title="لوحة التحكم الرئيسية" subtitle="نظرة عامة على أداء الشركة" />
      <div className="p-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard title="إجمالي الإيرادات" value={`${fmt(summary.totalRevenue)} ج.م`} color="text-emerald-600" sub="من أوامر التوريد المسلّمة" />
          <StatCard
            title="صافي الربح / الخسارة"
            value={`${fmt(summary.netProfit)} ج.م`}
            color={summary.netProfit >= 0 ? "text-emerald-600" : "text-red-600"}
            sub={`هامش الربح: ${summary.profitMargin}%`}
          />
          <StatCard title="إجمالي التكاليف" value={`${fmt(summary.totalCosts)} ج.م`} color="text-red-600" sub="مباشرة + غير مباشرة + إنتاج" />
          <StatCard title="قيمة المخزون" value={`${fmt(totalInventoryValue)} ج.م`} color="text-blue-600" sub={`${inventory.length} منتج`} />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <StatCard title="التكاليف المباشرة" value={`${fmt(summary.totalDirectCosts)} ج.م`} color="text-blue-600" />
          <StatCard title="التكاليف غير المباشرة" value={`${fmt(summary.totalIndirectCosts)} ج.م`} color="text-purple-600" />
          <StatCard title="تكاليف الإنتاج" value={`${fmt(summary.totalProductionCosts)} ج.م`} color="text-amber-600" />
          <StatCard title="عدد المنتجات" value={products.length} sub="منتج مسجل" />
        </div>

        {mounted && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-base font-bold text-gray-900 mb-4">المبيعات الشهرية</h2>
              <Bar data={salesChartData} options={{ responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }} />
            </div>
            <div className="bg-white rounded-xl shadow-sm border p-6">
              <h2 className="text-base font-bold text-gray-900 mb-4">توزيع التكاليف</h2>
              <div className="max-w-xs mx-auto">
                <Doughnut data={expenseTypeData} options={{ responsive: true, plugins: { legend: { position: 'bottom' } } }} />
              </div>
            </div>
            {catChartData.labels.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm border p-6 lg:col-span-2">
                <h2 className="text-base font-bold text-gray-900 mb-4">المصروفات حسب الفئة</h2>
                <Bar data={catChartData} options={{ responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }} />
              </div>
            )}
          </div>
        )}
      </div>
    </Layout>
  )
}
