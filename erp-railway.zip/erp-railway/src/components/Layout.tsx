import { Link, useLocation } from "@tanstack/react-router";
import {
  LayoutDashboard, Package, Factory, ClipboardList, Warehouse,
  FileCheck, Truck, ReceiptText, Users, Calculator, TrendingUp,
  Megaphone, ChevronRight, Building2, Target, FlaskConical
} from "lucide-react";

const navItems = [
  { to: "/", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/products", label: "المنتجات", icon: Package },
  { to: "/materials", label: "المواد الخام والتغليف", icon: FlaskConical },
  { to: "/cmos", label: "المصانع", icon: Factory },
  { to: "/production", label: "أوامر الإنتاج", icon: ClipboardList },
  { to: "/inventory", label: "المخزون", icon: Warehouse },
  { to: "/registration", label: "التسجيل الدوائي", icon: FileCheck },
  { to: "/distributors", label: "الموزعون", icon: Building2 },
  { to: "/deliveries", label: "التوريد والمبيعات", icon: Truck },
  { to: "/expenses", label: "المصروفات", icon: ReceiptText },
  { to: "/employees", label: "الموظفون", icon: Users },
  { to: "/budget", label: "الميزانية", icon: Calculator },
  { to: "/marketing", label: "الدعاية والمبيعات", icon: Megaphone },
  { to: "/reports", label: "التقارير المالية", icon: TrendingUp },
];

export function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();

  return (
    <div className="flex min-h-screen bg-gray-50" dir="rtl">
      {/* Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col fixed h-full z-10 shadow-xl">
        <div className="p-5 border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-500 flex items-center justify-center">
              <span className="text-white font-bold text-lg">ف</span>
            </div>
            <div>
              <p className="font-bold text-sm leading-tight">نظام إدارة</p>
              <p className="text-emerald-400 text-xs">الشركة الدوائية</p>
            </div>
          </div>
        </div>

        <nav className="flex-1 overflow-y-auto py-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.to;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 px-4 py-2.5 text-sm transition-all duration-150 mx-2 rounded-lg mb-0.5 ${
                  isActive
                    ? "bg-emerald-600 text-white font-semibold"
                    : "text-slate-300 hover:bg-slate-800 hover:text-white"
                }`}
              >
                <Icon size={17} />
                <span className="flex-1">{item.label}</span>
                {isActive && <ChevronRight size={14} />}
              </Link>
            );
          })}
        </nav>

        <div className="p-4 border-t border-slate-700">
          <p className="text-slate-500 text-xs text-center">نظام ERP الدوائي v1.0</p>
        </div>
      </aside>

      {/* Main Content */}
      <main className="mr-64 flex-1 overflow-auto">
        {children}
      </main>
    </div>
  );
}

export function PageHeader({ title, subtitle, action }: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="bg-white border-b px-8 py-5 flex items-center justify-between sticky top-0 z-10 shadow-sm">
      <div>
        <h1 className="text-xl font-bold text-gray-900">{title}</h1>
        {subtitle && <p className="text-sm text-gray-500 mt-0.5">{subtitle}</p>}
      </div>
      {action && <div>{action}</div>}
    </div>
  );
}

export function StatCard({ title, value, sub, color }: {
  title: string; value: string | number; sub?: string; color?: string;
}) {
  return (
    <div className="bg-white rounded-xl shadow-sm border p-5">
      <p className="text-sm text-gray-500 mb-1">{title}</p>
      <p className={`text-2xl font-bold ${color ?? "text-gray-900"}`}>{value}</p>
      {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
    </div>
  );
}

export function Badge({ status }: { status: string }) {
  const map: Record<string, string> = {
    active: "bg-emerald-100 text-emerald-700",
    inactive: "bg-gray-100 text-gray-600",
    pending: "bg-amber-100 text-amber-700",
    in_production: "bg-blue-100 text-blue-700",
    received: "bg-emerald-100 text-emerald-700",
    delivered: "bg-emerald-100 text-emerald-700",
    cancelled: "bg-red-100 text-red-700",
    expired: "bg-red-100 text-red-700",
    direct: "bg-blue-100 text-blue-700",
    indirect: "bg-purple-100 text-purple-700",
    raw_material: "bg-blue-100 text-blue-700",
    packaging: "bg-purple-100 text-purple-700",
  };
  const labels: Record<string, string> = {
    active: "نشط", inactive: "غير نشط", pending: "قيد الانتظار",
    in_production: "في الإنتاج", received: "مستلم", delivered: "مسلّم",
    cancelled: "ملغي", expired: "منتهي", direct: "مباشر", indirect: "غير مباشر",
    raw_material: "مادة خام", packaging: "تغليف",
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${map[status] ?? "bg-gray-100 text-gray-600"}`}>
      {labels[status] ?? status}
    </span>
  );
}

export function Modal({ open, onClose, title, children }: {
  open: boolean; onClose: () => void; title: string; children: React.ReactNode;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h2 className="text-lg font-bold text-gray-900">{title}</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">&times;</button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}

export function Input({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <input
        {...props}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
      />
    </div>
  );
}

export function Select({ label, children, ...props }: {
  label: string; children: React.ReactNode;
} & React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <select
        {...props}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent bg-white"
      >
        {children}
      </select>
    </div>
  );
}

export function Textarea({ label, ...props }: { label: string } & React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      <textarea
        {...props}
        rows={3}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
      />
    </div>
  );
}

export function Btn({ children, variant = "primary", ...props }: {
  children: React.ReactNode; variant?: "primary" | "secondary" | "danger";
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const cls = {
    primary: "bg-emerald-600 hover:bg-emerald-700 text-white",
    secondary: "bg-gray-100 hover:bg-gray-200 text-gray-700",
    danger: "bg-red-600 hover:bg-red-700 text-white",
  };
  return (
    <button
      {...props}
      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors disabled:opacity-50 ${cls[variant]}`}
    >
      {children}
    </button>
  );
}

export function Table({ headers, children, empty }: {
  headers: string[]; children: React.ReactNode; empty?: boolean;
}) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b border-gray-200 bg-gray-50">
            {headers.map((h, i) => (
              <th key={i} className="text-right py-3 px-4 font-semibold text-gray-600 text-xs uppercase tracking-wide">
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {empty ? (
            <tr>
              <td colSpan={headers.length} className="py-12 text-center text-gray-400">
                لا توجد بيانات بعد
              </td>
            </tr>
          ) : children}
        </tbody>
      </table>
    </div>
  );
}

export function fmt(num: number | string | null | undefined): string {
  const n = Number(num ?? 0);
  return n.toLocaleString("ar-EG", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
