# نظام ERP الدوائي - Railway Deployment

## خطوات الرفع على Railway

### 1. إنشاء حساب على Railway
- اذهب إلى [railway.app](https://railway.app)
- سجّل دخول بحساب GitHub

### 2. رفع الكود على GitHub
- اذهب إلى [github.com](https://github.com) وأنشئ Repository جديد
- ارفع محتويات هذا الملف

### 3. إنشاء المشروع على Railway
1. اضغط **New Project**
2. اختر **Deploy from GitHub repo**
3. اختر الـ Repository اللي رفعته

### 4. إضافة قاعدة البيانات
1. داخل المشروع اضغط **+ Add Service**
2. اختر **Database → PostgreSQL**
3. Railway هينشئ قاعدة بيانات تلقائياً

### 5. ربط البيانات
1. روح على **Variables** في الـ web service
2. أضف متغير:
   ```
   DATABASE_URL = ${{Postgres.DATABASE_URL}}
   ```
   (Railway بيملأها تلقائياً من PostgreSQL service)

### 6. تشغيل Migration
1. في Railway dashboard → **Web Service → Settings**
2. في **Start Command** حط:
   ```
   npm run db:push && npm run start
   ```

### النتيجة
- النظام هيشتغل على رابط زي: `https://your-project.railway.app`
- البيانات بتتحفظ في PostgreSQL بشكل دائم

## Tech Stack
- **Frontend**: React + TanStack Router
- **Backend**: TanStack Start (Server Functions)
- **Database**: PostgreSQL + Drizzle ORM
- **Hosting**: Railway.app
