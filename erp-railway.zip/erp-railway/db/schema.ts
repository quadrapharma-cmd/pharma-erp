import { pgTable, serial, text, integer, timestamp, date, numeric } from "drizzle-orm/pg-core";

// المنتجات
export const products = pgTable("products", {
  id: serial().primaryKey(),
  name: text().notNull(),
  scientificName: text("scientific_name"),
  dosageForm: text("dosage_form").notNull(),
  strength: text(),
  unit: text().default("علبة"),
  sellingPrice: numeric("selling_price", { precision: 12, scale: 2 }),
  status: text().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// المصانع (CMOs)
export const cmos = pgTable("cmos", {
  id: serial().primaryKey(),
  name: text().notNull(),
  address: text(),
  contactPerson: text("contact_person"),
  phone: text(),
  email: text(),
  licenseNumber: text("license_number"),
  status: text().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// التسجيل الدوائي
export const drugRegistrations = pgTable("drug_registrations", {
  id: serial().primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  registrationNumber: text("registration_number"),
  issueDate: date("issue_date"),
  expiryDate: date("expiry_date"),
  registrationFee: numeric("registration_fee", { precision: 12, scale: 2 }),
  renewalFee: numeric("renewal_fee", { precision: 12, scale: 2 }),
  status: text().default("active"),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// أوامر الإنتاج
export const productionOrders = pgTable("production_orders", {
  id: serial().primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  cmoId: integer("cmo_id").notNull().references(() => cmos.id),
  orderNumber: text("order_number"),
  quantity: integer().notNull(),
  unitCost: numeric("unit_cost", { precision: 12, scale: 2 }),
  totalCost: numeric("total_cost", { precision: 12, scale: 2 }),
  orderDate: date("order_date"),
  expectedDate: date("expected_date"),
  status: text().default("pending"),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// استلام البضاعة
export const goodsReceipts = pgTable("goods_receipts", {
  id: serial().primaryKey(),
  productionOrderId: integer("production_order_id").references(() => productionOrders.id),
  productId: integer("product_id").notNull().references(() => products.id),
  quantityReceived: integer("quantity_received").notNull(),
  batchNumber: text("batch_number"),
  expiryDate: date("expiry_date"),
  receiptDate: date("receipt_date"),
  unitCost: numeric("unit_cost", { precision: 12, scale: 2 }),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// المخزون
export const inventory = pgTable("inventory", {
  id: serial().primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  batchNumber: text("batch_number"),
  quantity: integer().notNull().default(0),
  unitCost: numeric("unit_cost", { precision: 12, scale: 2 }),
  expiryDate: date("expiry_date"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// شركات التوزيع
export const distributors = pgTable("distributors", {
  id: serial().primaryKey(),
  name: text().notNull(),
  address: text(),
  contactPerson: text("contact_person"),
  phone: text(),
  email: text(),
  creditLimit: numeric("credit_limit", { precision: 12, scale: 2 }),
  status: text().default("active"),
  createdAt: timestamp("created_at").defaultNow(),
});

// أوامر التوريد
export const deliveryOrders = pgTable("delivery_orders", {
  id: serial().primaryKey(),
  orderNumber: text("order_number"),
  distributorId: integer("distributor_id").notNull().references(() => distributors.id),
  orderDate: date("order_date"),
  status: text().default("pending"),
  totalAmount: numeric("total_amount", { precision: 12, scale: 2 }),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// بنود أوامر التوريد
export const deliveryOrderItems = pgTable("delivery_order_items", {
  id: serial().primaryKey(),
  deliveryOrderId: integer("delivery_order_id").notNull().references(() => deliveryOrders.id),
  productId: integer("product_id").notNull().references(() => products.id),
  quantity: integer().notNull(),
  unitPrice: numeric("unit_price", { precision: 12, scale: 2 }),
  totalPrice: numeric("total_price", { precision: 12, scale: 2 }),
});

// المصروفات
export const expenses = pgTable("expenses", {
  id: serial().primaryKey(),
  description: text().notNull(),
  amount: numeric({ precision: 12, scale: 2 }).notNull(),
  expenseType: text("expense_type").notNull(), // direct, indirect
  category: text().notNull(),
  department: text(),
  expenseDate: date("expense_date"),
  reference: text(),
  productId: integer("product_id").references(() => products.id),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// الموظفون
export const employees = pgTable("employees", {
  id: serial().primaryKey(),
  name: text().notNull(),
  department: text().notNull(),
  position: text().notNull(),
  salary: numeric({ precision: 12, scale: 2 }),
  hireDate: date("hire_date"),
  status: text().default("active"),
  phone: text(),
  email: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// الميزانية
export const budgetLines = pgTable("budget_lines", {
  id: serial().primaryKey(),
  year: integer().notNull(),
  month: integer(),
  department: text(),
  category: text().notNull(),
  description: text(),
  budgetedAmount: numeric("budgeted_amount", { precision: 12, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// حملات الدعاية
export const marketingCampaigns = pgTable("marketing_campaigns", {
  id: serial().primaryKey(),
  name: text().notNull(),
  productId: integer("product_id").references(() => products.id),
  startDate: date("start_date"),
  endDate: date("end_date"),
  budget: numeric({ precision: 12, scale: 2 }),
  actualSpend: numeric("actual_spend", { precision: 12, scale: 2 }).default("0"),
  status: text().default("active"),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// أهداف المبيعات
export const salesTargets = pgTable("sales_targets", {
  id: serial().primaryKey(),
  productId: integer("product_id").references(() => products.id),
  distributorId: integer("distributor_id").references(() => distributors.id),
  year: integer().notNull(),
  month: integer(),
  targetQuantity: integer("target_quantity"),
  targetAmount: numeric("target_amount", { precision: 12, scale: 2 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// المواد الخام ومواد التغليف
export const materials = pgTable("materials", {
  id: serial().primaryKey(),
  name: text().notNull(),
  materialType: text("material_type").notNull(), // raw_material, packaging
  unit: text().notNull(),
  currentStock: numeric("current_stock", { precision: 12, scale: 3 }).default("0"),
  reorderLevel: numeric("reorder_level", { precision: 12, scale: 3 }),
  unitCost: numeric("unit_cost", { precision: 12, scale: 4 }),
  supplier: text(),
  status: text().default("active"),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// استلام المواد (دُفعات مع تتبع الصلاحية)
export const materialReceipts = pgTable("material_receipts", {
  id: serial().primaryKey(),
  materialId: integer("material_id").notNull().references(() => materials.id),
  quantityReceived: numeric("quantity_received", { precision: 12, scale: 3 }).notNull(),
  batchNumber: text("batch_number"),
  expiryDate: date("expiry_date"),
  receiptDate: date("receipt_date"),
  unitCost: numeric("unit_cost", { precision: 12, scale: 4 }),
  supplier: text(),
  invoiceNumber: text("invoice_number"),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});

// قائمة مكونات المنتج - BOM
export const productBOM = pgTable("product_bom", {
  id: serial().primaryKey(),
  productId: integer("product_id").notNull().references(() => products.id),
  materialId: integer("material_id").notNull().references(() => materials.id),
  quantityPerUnit: numeric("quantity_per_unit", { precision: 12, scale: 4 }).notNull(),
  notes: text(),
  createdAt: timestamp("created_at").defaultNow(),
});
