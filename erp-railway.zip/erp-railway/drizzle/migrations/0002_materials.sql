CREATE TABLE "material_receipts" (
	"id" serial PRIMARY KEY,
	"material_id" integer NOT NULL,
	"quantity_received" numeric(12,3) NOT NULL,
	"batch_number" text,
	"expiry_date" date,
	"receipt_date" date,
	"unit_cost" numeric(12,4),
	"supplier" text,
	"invoice_number" text,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "materials" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"material_type" text NOT NULL,
	"unit" text NOT NULL,
	"current_stock" numeric(12,3) DEFAULT '0',
	"reorder_level" numeric(12,3),
	"unit_cost" numeric(12,4),
	"supplier" text,
	"status" text DEFAULT 'active',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "product_bom" (
	"id" serial PRIMARY KEY,
	"product_id" integer NOT NULL,
	"material_id" integer NOT NULL,
	"quantity_per_unit" numeric(12,4) NOT NULL,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "material_receipts" ADD CONSTRAINT "material_receipts_material_id_materials_id_fkey" FOREIGN KEY ("material_id") REFERENCES "materials"("id");--> statement-breakpoint
ALTER TABLE "product_bom" ADD CONSTRAINT "product_bom_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "product_bom" ADD CONSTRAINT "product_bom_material_id_materials_id_fkey" FOREIGN KEY ("material_id") REFERENCES "materials"("id");