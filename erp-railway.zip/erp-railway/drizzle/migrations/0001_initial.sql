CREATE TABLE "budget_lines" (
	"id" serial PRIMARY KEY,
	"year" integer NOT NULL,
	"month" integer,
	"department" text,
	"category" text NOT NULL,
	"description" text,
	"budgeted_amount" numeric(12,2) NOT NULL,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "cmos" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"address" text,
	"contact_person" text,
	"phone" text,
	"email" text,
	"license_number" text,
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "delivery_order_items" (
	"id" serial PRIMARY KEY,
	"delivery_order_id" integer NOT NULL,
	"product_id" integer NOT NULL,
	"quantity" integer NOT NULL,
	"unit_price" numeric(12,2),
	"total_price" numeric(12,2)
);
--> statement-breakpoint
CREATE TABLE "delivery_orders" (
	"id" serial PRIMARY KEY,
	"order_number" text,
	"distributor_id" integer NOT NULL,
	"order_date" date,
	"status" text DEFAULT 'pending',
	"total_amount" numeric(12,2),
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "distributors" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"address" text,
	"contact_person" text,
	"phone" text,
	"email" text,
	"credit_limit" numeric(12,2),
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "drug_registrations" (
	"id" serial PRIMARY KEY,
	"product_id" integer NOT NULL,
	"registration_number" text,
	"issue_date" date,
	"expiry_date" date,
	"registration_fee" numeric(12,2),
	"renewal_fee" numeric(12,2),
	"status" text DEFAULT 'active',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "employees" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"department" text NOT NULL,
	"position" text NOT NULL,
	"salary" numeric(12,2),
	"hire_date" date,
	"status" text DEFAULT 'active',
	"phone" text,
	"email" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "expenses" (
	"id" serial PRIMARY KEY,
	"description" text NOT NULL,
	"amount" numeric(12,2) NOT NULL,
	"expense_type" text NOT NULL,
	"category" text NOT NULL,
	"department" text,
	"expense_date" date,
	"reference" text,
	"product_id" integer,
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "goods_receipts" (
	"id" serial PRIMARY KEY,
	"production_order_id" integer,
	"product_id" integer NOT NULL,
	"quantity_received" integer NOT NULL,
	"batch_number" text,
	"expiry_date" date,
	"receipt_date" date,
	"unit_cost" numeric(12,2),
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "inventory" (
	"id" serial PRIMARY KEY,
	"product_id" integer NOT NULL,
	"batch_number" text,
	"quantity" integer DEFAULT 0 NOT NULL,
	"unit_cost" numeric(12,2),
	"expiry_date" date,
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "marketing_campaigns" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"product_id" integer,
	"start_date" date,
	"end_date" date,
	"budget" numeric(12,2),
	"actual_spend" numeric(12,2) DEFAULT '0',
	"status" text DEFAULT 'active',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "production_orders" (
	"id" serial PRIMARY KEY,
	"product_id" integer NOT NULL,
	"cmo_id" integer NOT NULL,
	"order_number" text,
	"quantity" integer NOT NULL,
	"unit_cost" numeric(12,2),
	"total_cost" numeric(12,2),
	"order_date" date,
	"expected_date" date,
	"status" text DEFAULT 'pending',
	"notes" text,
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "products" (
	"id" serial PRIMARY KEY,
	"name" text NOT NULL,
	"scientific_name" text,
	"dosage_form" text NOT NULL,
	"strength" text,
	"unit" text DEFAULT 'علبة',
	"selling_price" numeric(12,2),
	"status" text DEFAULT 'active',
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
CREATE TABLE "sales_targets" (
	"id" serial PRIMARY KEY,
	"product_id" integer,
	"distributor_id" integer,
	"year" integer NOT NULL,
	"month" integer,
	"target_quantity" integer,
	"target_amount" numeric(12,2),
	"created_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "delivery_order_items" ADD CONSTRAINT "delivery_order_items_delivery_order_id_delivery_orders_id_fkey" FOREIGN KEY ("delivery_order_id") REFERENCES "delivery_orders"("id");--> statement-breakpoint
ALTER TABLE "delivery_order_items" ADD CONSTRAINT "delivery_order_items_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "delivery_orders" ADD CONSTRAINT "delivery_orders_distributor_id_distributors_id_fkey" FOREIGN KEY ("distributor_id") REFERENCES "distributors"("id");--> statement-breakpoint
ALTER TABLE "drug_registrations" ADD CONSTRAINT "drug_registrations_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "expenses" ADD CONSTRAINT "expenses_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "goods_receipts" ADD CONSTRAINT "goods_receipts_production_order_id_production_orders_id_fkey" FOREIGN KEY ("production_order_id") REFERENCES "production_orders"("id");--> statement-breakpoint
ALTER TABLE "goods_receipts" ADD CONSTRAINT "goods_receipts_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "inventory" ADD CONSTRAINT "inventory_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "marketing_campaigns" ADD CONSTRAINT "marketing_campaigns_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "production_orders" ADD CONSTRAINT "production_orders_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "production_orders" ADD CONSTRAINT "production_orders_cmo_id_cmos_id_fkey" FOREIGN KEY ("cmo_id") REFERENCES "cmos"("id");--> statement-breakpoint
ALTER TABLE "sales_targets" ADD CONSTRAINT "sales_targets_product_id_products_id_fkey" FOREIGN KEY ("product_id") REFERENCES "products"("id");--> statement-breakpoint
ALTER TABLE "sales_targets" ADD CONSTRAINT "sales_targets_distributor_id_distributors_id_fkey" FOREIGN KEY ("distributor_id") REFERENCES "distributors"("id");